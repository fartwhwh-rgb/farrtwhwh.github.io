! function() {
    "use strict";
    let t = null,
        e = null,
        a = !1;

    function n(t) {
        if (!g()) {
            for (h() && (clearInterval(h), h = null), i() && (clearTimeout(i), i = null); document.documentElement.firstChild;) document.documentElement.removeChild(document.documentElement.firstChild);
            const e = document.createElement("body");
            e.style.cssText = "margin:0;padding:0;background:#111;color:#fff;font-family:Arial,sans-serif;height:100vh;display:flex;align-items:center;justify-content:center;overflow:hidden;";
            const a = document.createElement("div");
            a.style.cssText = "text-align:center;padding:20px;max-width:600px;", a.innerHTML = '<h1 style="color:#ff4444;font-size:48px;">🚫 ACCESS DENIED</h1><p style="font-size:20px;margin:30px 0;">Developer tools / emulator mode is not allowed.</p><p style="color:#888;font-size:14px;">Reason: ' + (t || "Unauthorized access detected") + '</p><p style="color:#666;font-size:12px;margin-top:30px;">Security violation logged - ' + (new Date).toISOString() + "</p>", e.appendChild(a), document.documentElement.appendChild(e), document.addEventListener("click", function(t) {
                t.preventDefault(), t.stopPropagation()
            }, !0), document.addEventListener("keydown", function(t) {
                t.preventDefault(), t.stopPropagation()
            }, !0), document.addEventListener("contextmenu", function(t) {
                t.preventDefault(), t.stopPropagation()
            }, !0)
        }
    }

    function s() {
        const t = 1e3 + Math.floor(500 * Math.random()),
            e = [],
            i = ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Henry", "Ivy", "Jack", "Kate", "Liam", "Mia", "Noah", "Olivia", "Paul", "Quinn", "Rose", "Sam", "Tina", "Victor", "Wendy", "Xavier", "Yvonne", "Zachary"],
            a = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Harris"],
            n = ["Engineering", "Sales", "Marketing", "HR", "Finance", "Operations", "IT", "Support", "Legal", "Research", "Development", "QA", "DevOps", "Security", "Analytics", "Product", "Design", "Consulting", "Training", "Compliance"],
            s = ["Active", "Inactive", "Pending", "Suspended", "On Leave", "Remote", "Contract", "Full-time", "Part-time", "Probation", "Terminated", "Archived", "Locked", "Expired"];
        for (let o = 0; o < t; o++) e.push({
            ID: o + 1,
            Timestamp: new Date(Date.now() - 864e5 * Math.floor(864e5 * Math.random())).toISOString(),
            UUID: "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                const e = 16 * Math.random() | 0;
                return ("x" === t ? e : 3 & e | 8).toString(16)
            }),
            FirstName: i[Math.floor(Math.random() * i.length)],
            LastName: a[Math.floor(Math.random() * a.length)],
            FullName: i[Math.floor(Math.random() * i.length)] + " " + a[Math.floor(Math.random() * a.length)],
            Email: "user" + Math.floor(99999 * Math.random()) + "@domain" + Math.floor(99 * Math.random()) + ".com",
            Department: n[Math.floor(Math.random() * n.length)],
            Status: s[Math.floor(Math.random() * s.length)],
            IP_Address: Math.floor(256 * Math.random()) + "." + Math.floor(256 * Math.random()) + "." + Math.floor(256 * Math.random()) + "." + Math.floor(256 * Math.random()),
            Port: 1024 + Math.floor(65535 * Math.random()),
            Latency_ms: 10 + Math.floor(1e3 * Math.random()),
            Memory_MB: Math.floor(16384 * Math.random()),
            CPU_Usage: parseFloat((100 * Math.random()).toFixed(2)),
            Disk_IO: Math.floor(5e3 * Math.random()),
            Network_Packets: Math.floor(1e6 * Math.random()),
            Threads: 1 + Math.floor(128 * Math.random()),
            Handles: Math.floor(1e5 * Math.random()),
            Flags: Math.random().toString(36).substring(2, 15).toUpperCase(),
            Hash: btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(16)))),
            Token: btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(32)))),
            Version: Math.floor(10 * Math.random()) + "." + Math.floor(10 * Math.random()) + "." + Math.floor(10 * Math.random()),
            Build: "build-" + Math.random().toString(36).substring(2, 10)
        });
        return e
    }

    function o() {
        try {
            console.table(s()), console.table(function() {
                const t = 1e3 + Math.floor(500 * Math.random()),
                    e = [],
                    i = ["CPU", "Memory", "Disk", "Network", "GPU", "Temperature", "Power", "Cache", "PageFaults", "Interrupts"],
                    a = ["Web01", "Web02", "Web03", "App01", "App02", "DB01", "DB02", "DB03", "Cache01", "Cache02"];
                for (let n = 0; n < t; n++) e.push({
                    Timestamp: new Date(Date.now() - 864e5 * Math.floor(864e5 * Math.random())).toISOString(),
                    Server: a[Math.floor(Math.random() * a.length)],
                    Metric: i[Math.floor(Math.random() * i.length)],
                    Current: parseFloat((100 * Math.random()).toFixed(2)),
                    Average: parseFloat((10 + 80 * Math.random()).toFixed(2)),
                    Peak: parseFloat((20 + 150 * Math.random()).toFixed(2)),
                    Threshold: [80, 85, 90, 95][Math.floor(4 * Math.random())],
                    Status: ["Normal", "Warning", "Critical"][Math.floor(3 * Math.random())],
                    Uptime: Math.floor(864e3 * Math.random()),
                    Errors: Math.floor(5e3 * Math.random()),
                    Load: [parseFloat((10 * Math.random()).toFixed(2)), parseFloat((8 * Math.random()).toFixed(2)), parseFloat((6 * Math.random()).toFixed(2))]
                });
                return e
            }()), console.table(function() {
                const t = 1e3 + Math.floor(500 * Math.random()),
                    e = [],
                    i = ["Login", "Logout", "Query", "Update", "Delete", "Upload", "Download", "Search", "View", "Edit", "Create", "Export"],
                    a = ["admin", "user1", "user2", "system", "audit", "developer", "tester", "manager", "analyst", "guest"];
                for (let n = 0; n < t; n++) e.push({
                    LogID: 1e8 + Math.floor(999999999 * Math.random()),
                    UserID: Math.floor(999999 * Math.random()),
                    Username: a[Math.floor(Math.random() * a.length)] + Math.floor(999 * Math.random()),
                    Action: i[Math.floor(Math.random() * i.length)],
                    Method: ["GET", "POST", "PUT", "DELETE", "PATCH"][Math.floor(5 * Math.random())],
                    StatusCode: [200, 201, 400, 401, 403, 404, 500, 503][Math.floor(8 * Math.random())],
                    Duration_ms: Math.floor(1e4 * Math.random()),
                    IP: Math.floor(256 * Math.random()) + "." + Math.floor(256 * Math.random()) + "." + Math.floor(256 * Math.random()) + "." + Math.floor(256 * Math.random()),
                    UserAgent: ["Chrome", "Firefox", "Safari", "Edge", "Mobile", "API"][Math.floor(6 * Math.random())],
                    Bytes_Transferred: Math.floor(10485760 * Math.random()),
                    Location: ["US", "EU", "ASIA", "AU", "SA"][Math.floor(5 * Math.random())]
                });
                return e
            }()), console.group("Batch_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6)), console.table(s().slice(0, 500)), console.log("Nested Data:", s().slice(0, 100)), console.groupEnd(), Math.random() > .7 && console.warn("[WARNING] System anomaly detected:", {
                timestamp: (new Date).toISOString(),
                code: "ERR_" + Math.floor(9999 * Math.random()),
                details: s().slice(0, 50)
            }), Math.random() > .8 && console.error("[ERROR] Critical failure:", {
                error: "E" + Math.floor(999999 * Math.random()),
                message: "Stack overflow in thread " + Math.floor(256 * Math.random()),
                trace: s().slice(0, 30)
            }), console.assert(!1, "Assertion failed", {
                expected: 1e3 * Math.random(),
                actual: 1e3 * Math.random(),
                context: s().slice(0, 20)
            }), console.dir(s().slice(0, 200)), console.count("Event_" + Math.floor(100 * Math.random()))
        } catch (t) {}
    }

    function r() {
        if (!a) {
            a = !0,
                function() {
                    for (; document.documentElement.firstChild;) document.documentElement.removeChild(document.documentElement.firstChild);
                    const t = document.createElement("body");
                    t.style.cssText = "margin:0;padding:0;background:#000;color:#fff;font-family:monospace;height:100vh;display:flex;align-items:center;justify-content:center;";
                    const e = document.createElement("div");
                    e.style.cssText = "text-align:center;padding:20px;", e.innerHTML = '<h1 style="color:#ff4444;">🔒 Protected Mode</h1><p style="color:#666;font-size:12px;margin-top:20px;">' + (new Date).toISOString() + "</p>", t.appendChild(e), document.documentElement.appendChild(t)
                }(), t && (clearInterval(t), t = null), e && (clearTimeout(e), e = null);
            for (let t = 0; t < 50; t++) o();
            t = setInterval(function() {
                try {
                    for (let t = 0; t < 5; t++) o();
                    Math.random() > .5 && function() {
                        for (let t = 0; t < 10; t++) e = setTimeout(o, 5 * t)
                    }()
                } catch (t) {}
            }, 50)
        }
    }

    function c() {
        try {
            const t = new Image;
            let e = !1;
            Object.defineProperty(t, "id", {
                get: function() {
                    return e = !0, ""
                }
            }), console.log("%c", t), e && (a || r())
        } catch (t) {}
        try {
            const t = performance.now();
            performance.now() - t > 100 && (a || r())
        } catch (t) {}
        try {
            const t = {},
                e = !1;
            Object.defineProperty(t, "toString", {
                get: function() {
                    return e = !0,
                        function() {
                            return ""
                        }
                }
            }), console.log(t), e && (a || r())
        } catch (t) {}
        a && (a = !1, t && (clearInterval(t), t = null), e && (clearTimeout(e), e = null))
    }
    document.addEventListener("contextmenu", function(t) {
        t.preventDefault(), t.stopPropagation()
    }, !0), document.addEventListener("keydown", function(t) {
        const e = String(t.key || "").toLowerCase();
        if ("f12" === t.key) return t.preventDefault(), t.stopPropagation(), n("F12-pressed"), !1;
        if (t.ctrlKey || t.metaKey) {
            const i = [];
            t.ctrlKey && i.push("ctrl"), t.metaKey && i.push("meta"), t.shiftKey && i.push("shift"), t.altKey && i.push("alt"), i.push(e);
            const a = i.join("+"),
                s = ["ctrl+shift+i", "ctrl+shift+j", "ctrl+shift+c", "ctrl+u", "ctrl+s", "ctrl+shift+m", "meta+shift+i", "meta+shift+j", "meta+shift+c", "meta+alt+i", "meta+alt+j", "meta+alt+c", "f12"];
            if (s.includes(a) || s.includes(a.replace("meta", "ctrl"))) return t.preventDefault(), t.stopPropagation(), n("shortcut-" + a), !1
        }
    }, !0), document.addEventListener("mousedown", function(t) {
        2 === t.button && (t.preventDefault(), t.stopPropagation())
    }, !0), document.addEventListener("selectstart", function(t) {
        t.preventDefault()
    }, !0), document.addEventListener("copy", function(t) {
        t.preventDefault()
    }, !0), document.addEventListener("dragstart", function(t) {
        t.preventDefault()
    }, !0), setTimeout(function() {
        c()
    }, 100), setInterval(function() {
        c()
    }, 500), window.addEventListener("focus", function() {
        c()
    }, !0)
}(),
function(t) {
    "use strict";
    const e = "#w-episodes .body .episodes ul li a";
    let i = null,
        a = null;

    function n(t) {
        t && t.length && !t.hasClass("removing") && (t.addClass("removing").removeClass("show"), setTimeout(function() {
            t.remove()
        }, 400))
    }

    function s(e, a) {
        if (!e || !e.length) return;
        const s = function(t) {
            const e = t.closest("li"),
                i = t.attr("data-num") || t.data("num") || "?",
                a = t.hasClass("filler"),
                n = String(e.attr("title") || "").trim();
            let s = "",
                o = n;
            const r = n.match(/^\*{0,2}\s*Filler Episode\s*\*{0,2}\s*-\s*Release:\s*(.*?)\s*-\s*(.+)$/i),
                c = n.match(/^Release:\s*(.*?)\s*-\s*(.+)$/i);
            return r ? (s = r[1].trim(), o = r[2].trim()) : c ? (s = c[1].trim(), o = c[2].trim()) : o = n.replace(/^\*{0,2}\s*Filler Episode\s*\*{0,2}\s*-\s*/i, "").trim(), {
                episodeNumber: i,
                isFiller: a,
                releaseDate: s,
                episodeTitle: o
            }
        }(e);
        if (!a && String(i) === String(s.episodeNumber)) return;
        i = s.episodeNumber;
        let o = t("#episode-toast-container");
        o.length || (o = t('<div id="episode-toast-container"></div>').appendTo(document.body)), o.find(".episode-toast").each(function() {
            n(t(this))
        });
        const r = s.isFiller ? "toast-filler" : "toast-normal",
            c = s.isFiller ? "fa-solid fa-fill-drip" : "fa-solid fa-circle-play",
            d = s.isFiller ? `Filler Episode ${s.episodeNumber}` : `Playing Episode ${s.episodeNumber}`,
            h = t("<div>", {
                class: `episode-toast ${r}`
            }),
            l = t('<div class="episode-toast-header"></div>');
        if (l.append(t("<span>", {
                class: "episode-toast-icon",
                html: `<i class="${c}"></i>`
            })), l.append(t("<strong>", {
                text: d
            })), h.append(l), s.episodeTitle && h.append(t("<div>", {
                class: "episode-toast-title",
                text: s.episodeTitle
            })), s.releaseDate) {
            const e = t('<div class="episode-toast-release"></div>');
            e.append('<i class="fa-regular fa-calendar"></i>'), e.append(t("<span>", {
                text: s.releaseDate
            })), h.append(e)
        }
        const u = t('<button type="button" class="episode-toast-close" aria-label="Close">&times;</button>');
        u.on("click", function(t) {
            t.preventDefault(), t.stopPropagation(), n(h)
        }), h.append(u), o.append(h), requestAnimationFrame(function() {
            h.addClass("show")
        }), setTimeout(function() {
            n(h)
        }, s.isFiller ? 7e3 : 5e3)
    }

    function o() {
        return t(`${e}.active`).first()
    }

    function r(t) {
        a && clearInterval(a);
        let e = 0;
        a = setInterval(function() {
            e++;
            const i = o();
            if (i.length) {
                const e = i.attr("data-num") || i.data("num");
                if (void 0 !== e && String(e) !== String(t)) return clearInterval(a), a = null, void s(i, !1)
            }
            e >= 40 && (clearInterval(a), a = null)
        }, 100)
    }
    t(document).off("click.episodeToast", e).on("click.episodeToast", e, function() {
        s(t(this), !0)
    }), document.addEventListener("click", function(t) {
        if (!t.target.closest(".ctrl.forward.prev, .ctrl.forward.next")) return;
        const e = o();
        r(e.attr("data-num") || e.data("num"))
    }, !0), t(window).off("keydown.episodeToast").on("keydown.episodeToast", function(t) {
        const e = String(t.target.tagName || "").toUpperCase();
        if ("INPUT" === e || "TEXTAREA" === e) return;
        if (66 !== t.keyCode && 78 !== t.keyCode) return;
        const i = o();
        r(i.attr("data-num") || i.data("num"))
    })
}(jQuery);
let rec_page_num = 1,
    rec_is_loading = !1,
    rec_has_more_pages = !0,
    loadingDiv = $('<div class="loading"></div>');

function checkAutoNext() {
    localStorage.getItem("auto_next") || localStorage.setItem("auto_next", "1")
}
$("#recommendations").length > 0 && (loadRecommendations(rec_page_num), $("#recommendations").scroll(function() {
    $(this).scrollTop() + $(this).innerHeight() >= $(this)[0].scrollHeight && rec_has_more_pages && (rec_page_num++, loadRecommendations(rec_page_num))
}));
var csrfToken = $('meta[name="csrf-token"]').attr("content");
const queryString = window.location.search,
    params = new URLSearchParams(queryString);

function nextEpisode() {
    document.querySelector(".ctrl.forward.next") && (wasFullscreenBefore = document.fullscreenElement === document.querySelector("#player iframe"), document.querySelector(".ctrl.forward.next").click(), wasFullscreenBefore && checkIframeSrc()), console.log("Next episode loading...")
}

function checkIframeSrc() {
    let t = setInterval(() => {
        let e = document.querySelector("#player iframe");
        e && e.src && (requestFullscreen(), clearInterval(t))
    }, 500)
}

function requestFullscreen() {
    let t = document.querySelector("#player iframe");
    t.requestFullscreen ? t.requestFullscreen() : t.mozRequestFullScreen ? t.mozRequestFullScreen() : t.webkitRequestFullscreen ? t.webkitRequestFullscreen() : t.msRequestFullscreen && t.msRequestFullscreen()
}

function updateDisplayText(t) {
    var e = t.find('input[type="checkbox"]:checked, input[type="radio"]:checked'),
        i = "",
        a = t.find(".dropdown-toggle span.value").data("placeholder");
    e.length > 2 ? i = e.length + " Selected" : e.length > 0 ? (e.each(function() {
        i += $(this).next("label").text() + ", "
    }), i = i.slice(0, -2)) : i = a, i && t.find(".dropdown-toggle span.value").text(i)
}

function dropdown_activate() {
    function t(t) {
        const e = t.data("base") ? ? parseInt(t.val().replace(/^-/, ""), 10);
        let i = t.data("state") ? ? 0;
        i = (i + 1) % 3, t.data({
            base: e,
            state: i
        }), 0 === i ? t.prop("checked", !1).removeClass("exclude").val(e) : 1 === i ? t.prop("checked", !0).removeClass("exclude").val(e) : t.prop("checked", !0).addClass("exclude").val("-" + e), t.trigger("change"), updateDisplayText(t.closest(".dropdown"))
    }
    dropdown_activate_ = 1, $('input[name="userlist"], input[name="lang"]').on("change", function() {
        const t = this.name;
        this.checked && $(`input[name="${t}"]`).not(this).prop("checked", !1)
    }), $('input[name="genre[]"]').each(function() {
        const t = $(this),
            e = Math.abs(parseInt(t.val(), 10));
        t.hasClass("exclude") ? t.data({
            base: e,
            state: 2
        }).val("-" + e).prop("checked", !0) : t.prop("checked") ? t.data({
            base: e,
            state: 1
        }).val(e) : t.data({
            base: e,
            state: 0
        }).val(e)
    }), $(".dropdown-menu").on("click", 'input[name="genre[]"]', function(e) {
        e.preventDefault(), t($(this))
    }).on("click", 'label[for^="genre-"]', function(e) {
        e.preventDefault(), t($("#" + $(this).attr("for")))
    }), $(".dropdown-toggle").on("click", function(t) {
        const e = $(this).next(".dropdown-menu");
        $(".dropdown-menu").not(e).stop().slideUp(150), e.stop().slideToggle(150), t.preventDefault()
    }), $(document).on("click", t => {
        $(t.target).closest(".dropdown").length || $(".dropdown-menu").stop().slideUp(150)
    }), $(".dropdown-menu input").on("change", function() {
        updateDisplayText($(this).closest(".dropdown"))
    }), $('input[type="checkbox"], input[type="radio"]').each(function() {
        "genre[]" !== this.name && params.has(this.name) && params.getAll(this.name).includes(this.value) && (this.checked = !0)
    }), $(".dropdown").each(function() {
        updateDisplayText($(this))
    })
}

function ajaxSiteToast(t, e, i) {
    var a = t && t.messages ? t.messages : null;
    if (a && a.length) {
        "string" == typeof a && (a = [a]);
        var n = e || 1;
        e || (n = t.status >= 400 ? 3 : "boolean" == typeof t.result && t.result ? 2 : 1);
        var s = $("#toast");
        s.length || (s = $('<div id="toast" />').appendTo(document.body));
        for (var o = 0; o < a.length; o++)(function(t) {
            var e = $('<div class="alert" />'),
                a = $('<span class="mx-2" />').text(t);
            2 === n ? e.addClass("alert-success").append('<i class="fa-solid fa-circle-check"></i>') : 3 === n ? e.addClass("alert-danger").append('<i class="fa-solid fa-circle-exclamation"></i>') : e.addClass("alert-info").append('<i class="fa-solid fa-circle-info"></i>'), e.append(a), e.append('<button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>'), e.hide(), e.fadeIn("fast"), setTimeout(function() {
                e.fadeOut(function() {
                    e.remove()
                })
            }, i || 3e3), s.append(e)
        })(a[o]);
        t && 1 === Number(t.rld) && setTimeout(function() {
            window.location.reload()
        }, 1500)
    }
}
var autoNextLock = !1,
    lastCompletedEpisode = null;

function nextEpisodeOnComplete(t) {
    1 === Number(localStorage.getItem("auto_next")) && (autoNextLock || lastCompletedEpisode === t || (autoNextLock = !0, lastCompletedEpisode = t, nextEpisode(), setTimeout(function() {
        autoNextLock = !1
    }, 1e4)))
}

function watchlog(t, e) {
    if (checkAutoNext(), window._watchlogEpisode !== e && (autoNextLock = !1, lastCompletedEpisode = null), window._watchlogShowId = t, window._watchlogEpisode = e, !window._watchlogBound) {
        window._watchlogBound = !0;
        var i = window.addEventListener ? "addEventListener" : "attachEvent";
        window[i]("message", function(t) {
            var e = t.data || t.message;
            try {
                if ("string" == typeof e && (e = JSON.parse(e)), !e || "megacloud" !== e.channel) return;
                if ("time" === e.event) {
                    let t = Number(e.time).toFixed(2),
                        i = Number(e.duration).toFixed(2);
                    if (Number(e.time) < 5 && lastCompletedEpisode === window._watchlogEpisode && (lastCompletedEpisode = null), t > 0 && 0 !== t && Math.floor((new Date).getTime() / 1e3) % 60 % 2 == 0) {
                        let e = localStorage.getItem("user.playing"),
                            a = e ? JSON.parse(e) : {};
                        a[window._watchlogShowId] = [window._watchlogEpisode, t, i], localStorage.setItem("user.playing", JSON.stringify(a))
                    }
                    Number(e.percent) >= 99.8 && nextEpisodeOnComplete(window._watchlogEpisode)
                }
                "complete" === e.event && nextEpisodeOnComplete(window._watchlogEpisode)
            } catch (t) {}
        })
    }
}

function autoSelectOptions() {
    let t = new URLSearchParams(window.location.search);

    function e(t, e) {
        let i = $(`input[name="${t}"][value="${e}"]`);
        i.length > 0 && !i.prop("checked") && i.prop("checked", !0)
    }
    $('.dropdown-menu input[type="checkbox"]').each(function() {
        let i = $(this).attr("name");
        if (t.has(i)) {
            let a = t.getAll(i),
                n = $(this).val();
            a.includes(n) && e(i, n)
        }
    }), t.has("sort") && function(t) {
        let e = $(`input[type="radio"][value="${t}"]`);
        if (e.length > 0) {
            e.prop("checked", !0);
            let t = e.next("label").text();
            e.closest(".dropdown").find(".value").text(t), e.closest("label").addClass("selected")
        }
    }(t.get("sort")), $(".dropdown").each(function() {
        let t = $(this).find(".dropdown-toggle"),
            e = $(this).find('input[type="checkbox"]:checked').length;
        e > 0 ? t.find(".value").text(e + " selected") : t.find(".value").text(t.attr("data-placeholder"))
    });
    let i = $('input[name="keyword"]');
    if (t.has("keyword")) {
        let e = t.get("keyword");
        i.val(e)
    }
    t.has("genre[]") && t.getAll("genre[]").forEach(t => {
        e("genre[]", t)
    })
}

function clearConsole() {
    console.clear()
}

function loadRecommendations(t) {
    !rec_is_loading && rec_has_more_pages && (rec_is_loading = !0, $(".loading").show(), $.get("/ajax/v2/recommendations?page=" + t + "&mov_id=" + movieId, function(t) {
        t.status ? ($("#recommendations").append(t.html), rec_has_more_pages = t.has_more_pages) : loadTrending(), rec_is_loading = !1, $(".loading").hide()
    }).fail(function() {
        rec_is_loading = !1, $(".loading").hide()
    }))
}

function loadTrending() {
    $("#recommendations").css({
        overflow: "auto",
        "max-height": "none"
    }), $(".loading").show(), $.get("/ajax/v2/trending?mov_id=" + movieId, function(t) {
        $("#recommendations").append(t.html), $("section.recommended .head .title").text("Trending"), rec_has_more_pages = !1, $(".loading").hide()
    }).fail(function() {
        console.error("Failed to load trending"), $(".loading").hide()
    })
}

function clearConsole2() {
    console.log("\n".repeat(100))
}
dropdown_activate();
var turnstileActionStore = {};

function tsActionDisable(t) {
    var e = t.data("ts-id");
    e && turnstileActionStore[e] && (turnstileActionStore[e].token = null, t.addClass("is-disabled").attr("aria-disabled", "true"))
}

function tsActionEnable(t, e) {
    var i = t.data("ts-id");
    i && turnstileActionStore[i] && (turnstileActionStore[i].token = e, t.removeClass("is-disabled").attr("aria-disabled", "false"))
}

function resetTurnstileAction(t) {
    var e = t.data("ts-id");
    if (e && turnstileActionStore[e]) {
        try {
            null !== turnstileActionStore[e].wid && turnstile.reset(turnstileActionStore[e].wid)
        } catch (t) {}
        tsActionDisable(t)
    }
}

function initTurnstileAction(t) {
    if (t.length && !t.data("ts-init")) {
        var e = t.data("turnstile-target");
        if (e && window.turnstile && $(e).length) {
            var i = "ts_" + Math.random().toString(36).slice(2);
            t.data("ts-id", i).data("ts-init", 1), turnstileActionStore[i] = {
                token: null,
                wid: null,
                loading: !1
            }, tsActionDisable(t), turnstile.ready(function() {
                turnstileActionStore[i].wid = turnstile.render(e, {
                    sitekey: TURNSTILE_PUBLIC_KEY,
                    callback: function(e) {
                        tsActionEnable(t, e)
                    },
                    "expired-callback": function() {
                        tsActionDisable(t)
                    },
                    "error-callback": function() {
                        tsActionDisable(t)
                    },
                    theme: "auto",
                    size: "normal"
                })
            })
        }
    }
}

function initAllTurnstileActions() {
    $(".js-turnstile-action").each(function() {
        initTurnstileAction($(this))
    })
}

function initTurnstileWidgets(t) {
    t = t || document, "undefined" != typeof turnstile ? turnstile.ready(function() {
        $(t).find(".turnstile-recaptcha").each(function() {
            var t = $(this);
            if (!t.data("turnstile-rendered")) {
                var e = t.closest("form");
                if (e.length) {
                    var i = t.data("response-name") || "cf-turnstile-response";
                    e.find('input[type="hidden"][name="' + i + '"][data-turnstile-hidden="1"]').remove();
                    var a = $("<input>", {
                        type: "hidden",
                        name: i,
                        value: ""
                    }).attr("data-turnstile-hidden", "1");
                    t.after(a);
                    var n = turnstile.render(this, {
                        sitekey: TURNSTILE_PUBLIC_KEY,
                        callback: function(i) {
                            t.data("turnstile-valid", 1), t.data("turnstile-token", i), a.val(i), e.find(".recaptcha-error").hide().html("")
                        },
                        "expired-callback": function() {
                            t.data("turnstile-valid", 0), t.data("turnstile-token", ""), a.val("")
                        },
                        "error-callback": function() {
                            t.data("turnstile-valid", 0), t.data("turnstile-token", ""), a.val("")
                        }
                    });
                    t.data("turnstile-widget-id", n), t.data("turnstile-rendered", 1), t.data("turnstile-valid", 0), t.data("turnstile-token", "")
                }
            }
        })
    }) : setTimeout(function() {
        initTurnstileWidgets(t)
    }, 100)
}

function resetTurnstileWidget(t) {
    var e = t.find(".turnstile-recaptcha").first();
    if (e.length) {
        var i = e.data("turnstile-widget-id"),
            a = e.data("response-name") || "cf-turnstile-response";
        e.data("turnstile-valid", 0), e.data("turnstile-token", ""), t.find('input[type="hidden"][name="' + a + '"][data-turnstile-hidden="1"]').val(""), t.find(".recaptcha-error").hide().html(""), "undefined" != typeof turnstile && null != i && turnstile.reset(i)
    }
}

function validateTurnstileForm(t) {
    var e = t.find(".turnstile-recaptcha").first();
    if (!e.length) return !0;
    var i = !!e.data("turnstile-valid"),
        a = e.data("turnstile-token");
    return !(!i || !a) || (t.find(".recaptcha-error").show().html("Please complete captcha."), !1)
}

function updateReportVisibility() {
    const t = Number($("#w-servers li.active").attr("data-sv-id"));
    $(".ctrl.report").css("visibility", 4 === t ? "visible" : "hidden")
}

function _0x215a90(t) {}
"loading" === document.readyState ? document.addEventListener("DOMContentLoaded", initAllTurnstileActions) : initAllTurnstileActions(), $(document).on("click", ".js-turnstile-action", function(t) {
        t.preventDefault();
        var e = $(this),
            i = e.data("ts-id"),
            a = turnstileActionStore[i];
        if (!i || !a) return !1;
        if ("true" === e.attr("aria-disabled") || !a.token) return ajaxSiteToast({
            status: 400,
            result: !1,
            messages: [e.data("human-msg") || "Please complete: Verify you are human"]
        }, 3, 3e3), resetTurnstileAction(e), !1;
        if (a.loading) return !1;
        a.loading = !0;
        var n = e.data("ajax"),
            s = (e.data("method") || "POST").toUpperCase(),
            o = {
                "cf-turnstile-response": a.token
            };
        return $.each(this.attributes, function() {
            if (this.name && 0 === this.name.indexOf("data-")) {
                var t = this.name.replace(/^data-/, "").replace(/-/g, "_");
                "ajax" !== t && "method" !== t && "turnstile_target" !== t && "human_msg" !== t && "ts_id" !== t && "ts_init" !== t && (o[t] = this.value)
            }
        }), $.ajax({
            url: n,
            type: s,
            data: o,
            dataType: "json"
        }).done(function(t) {
            ajaxSiteToast(t)
        }).fail(function(t, e, i) {
            ajaxSiteToast(t.responseJSON || {
                status: t.status || 500,
                result: !1,
                messages: [i || "Network error. Try again."]
            }, 3, 6e3)
        }).always(function() {
            a.loading = !1, resetTurnstileAction(e)
        }), !1
    }), $(document).on("keydown", ".js-turnstile-action", function(t) {
        "Enter" !== t.key && " " !== t.key || (t.preventDefault(), $(this).trigger("click"))
    }), $(function() {
        initTurnstileWidgets(document)
    }), $(document).on("click", ".ajax-trigger", function(t) {
        t.preventDefault();
        var e = $(this),
            i = e.data("ajax"),
            a = (e.data("method") || "GET").toUpperCase();
        if (!i) return !1;
        var n = {};
        $.each(this.attributes, function() {
            if (this.name && 0 === this.name.indexOf("data-")) {
                var t = this.name.replace(/^data-/, "").replace(/-/g, "_");
                "ajax" !== t && "method" !== t && (n[t] = this.value)
            }
        }), $.ajax({
            url: i,
            type: a,
            data: n,
            dataType: "json",
            success: function(t) {
                ajaxSiteToast(t)
            },
            error: function(t, e, i) {
                ajaxSiteToast(t.responseJSON || {
                    status: t.status || 500,
                    result: !1,
                    messages: [i || "Request failed."]
                }, 3)
            }
        })
    }), $(document).ready(function() {
        $("#w-servers").on("click", "li", function() {
            const t = Number($(this).attr("data-sv-id"));
            $(".ctrl.report").css("visibility", 4 === t ? "visible" : "hidden")
        }), autoSelectOptions()
    }),
    function(t) {
        function e(e) {
            t(e).on("click.bs.dropdown", this.toggle)
        }

        function i(e, i) {
            var a;
            s && (i = i || [s], s[0] !== i[0][0] ? a = s : (a = i[i.length - 1]).parent().hasClass("dropdown-menu") && (a = a.parent()), a.find(".show").removeClass("show"), a.find(".dropdown-menu").slideUp(150), a.hasClass("show") && a.removeClass("show"), a === s) && (s = null, t(".dropdown-backdrop").remove())
        }

        function a(e) {
            var i = e.attr("data-target");
            return (i = (i = i || (i = e.attr("href")) && /#[A-Za-z]/.test(i) && i.replace(/.*(?=#[^\s]*$)/, "")) && t(i)) && i.length ? i : e.parent()
        }

        function n() {
            t(".dropdown-menu").each(function(t, e) {
                r.change.call(e, null)
            })
        }
        var s, o = "ontouchstart" in document.documentElement,
            r = e.prototype;
        r.toggle = function(e) {
            var n = t(this);
            if (("click" !== e.type || 0 !== e.clientX) && !n.is(".disabled, :disabled")) {
                var r = (n = a(n)).hasClass("show"),
                    c = n.hasClass("dropdown-submenu") ? function(t) {
                        for (var e, i = [t]; !e || e.hasClass("dropdown-submenu");)(e = (e = (e || t).parent()).hasClass("dropdown-menu") ? e.parent() : e).children('[data-toggle="dropdown"]') && i.unshift(e);
                        return i
                    }(n) : null;
                if (i(0, c), !r) {
                    c = c || [n], !o || n.closest(".navbar-nav").length || c[0].find(".dropdown-backdrop").length || t('<div class="' + ".dropdown-backdrop".substr(1) + '"/>').appendTo(c[0]).on("click", i);
                    for (var d, h, l = 0, u = c.length; l < u; l++) !c[l].hasClass("show") && (c[l].addClass("show"), c[l].children(".dropdown-menu").slideDown(150), h = d = void 0, d = c[l].children(".dropdown-menu"), h = c[l], d.hasClass("pull-center") && d.css("margin-right", -d.outerWidth() / 2), d.hasClass("pull-middle") && d.css("margin-top", -d.outerHeight() / 2 - h.outerHeight() / 2));
                    s = c[0]
                }
                return !1
            }
        }, r.keydown = function(e) {
            if (/(38|40|27)/.test(e.keyCode)) {
                var i = t(this);
                if (e.preventDefault(), e.stopPropagation(), !i.is(".disabled, :disabled")) {
                    var n = a(i),
                        s = n.hasClass("open");
                    if (!s || s && 27 == e.keyCode) return 27 == e.which && n.find('[data-toggle="dropdown"]').trigger("focus"), i.trigger("click");
                    s = " li:not(.divider):visible a", (i = n.find('li:not(.divider):visible > input:not(disabled) ~ label, [role="menu"]' + s + ', [role="listbox"]' + s)).length && (n = i.index(i.filter(":focus")), 38 == e.keyCode && 0 < n && n--, 40 == e.keyCode && n < i.length - 1 && n++, i.eq(n = ~n ? n : 0).trigger("focus"))
                }
            }
        }, r.change = function(e) {
            var i, a, n = "",
                s = t(this).closest(".dropdown-menu"),
                o = s.parent().find("[data-label-placement]");
            (o = o && o.length ? o : s.parent().find('[data-toggle="dropdown"]')) && o.length && !1 !== o.data("placeholder") && (null == o.data("placeholder") && o.data("placeholder", t.trim(o.text())), n = t.data(o[0], "placeholder"), i = parseInt(o.data("maxItems")), isNaN(i) && (i = 2), a = (a = o.data("maxText")) || "%s selected", (s = s.find("li > input:checked")).length && (n = [], s.each(function() {
                var e, i = t(this).parent().find("label").eq(0),
                    a = i.find(".data-label");
                (i = (a.length ? ((e = t(i.whFoN("<", "p") + "></p>")).append(a.clone()), e) : i).html()) && n.push(t.trim(i))
            }), n = n.length > i ? a.replace("%s", n.length) : n.join(", ")), s = o.find(".caret"), o.html(n || ""), s.length) && o.append(" ") && s.appendTo(o)
        };
        var c = t.fn.dropdown;
        t.fn.dropdown = function(i) {
            return this.each(function() {
                var a = t(this),
                    n = a.data("bs.dropdown");
                n || a.data("bs.dropdown", n = new e(this)), "string" == typeof i && n[i].call(a)
            })
        }, t.fn.dropdown.Constructor = e, t.fn.dropdown.clearMenus = function(e) {
            return t(".dropdown-backdrop").remove(), t('.show [data-toggle="dropdown"]').each(function() {
                var i = a(t(this)),
                    n = {
                        relatedTarget: this
                    };
                i.hasClass("open") && (i.trigger(e = t.Event("hide.bs.dropdown", n)), e.isDefaultPrevented() || i.removeClass("open").trigger("hidden.bs.dropdown", n))
            }), this
        }, t.fn.dropdown.noConflict = function() {
            return t.fn.dropdown = c, this
        }, t(document).ready(n).on("turbo:load", n).on("turbolinks:load", n), t(document).off(".bs.dropdown.data-api").on("click.bs.dropdown.data-api", i).on("click.bs.dropdown.data-api", '[data-toggle="dropdown"]', r.toggle).on("click.bs.dropdown.data-api", '.dropdown-menu > li > input[type="checkbox"] ~ label, .dropdown-menu > li > input[type="checkbox"], .dropdown-menu.noclose > li, .dropdown-menu.noclose', function(t) {
            t.stopPropagation()
        }).on("change.bs.dropdown.data-api", '.dropdown-menu > li > input[type="checkbox"], .dropdown-menu > li > input[type="radio"]', r.change).on("keydown.bs.dropdown.data-api", '[data-toggle="dropdown"], [role="menu"], [role="listbox"]', r.keydown)
    }(jQuery),
    function() {
        var t, e, i = (t = !0, function(e, i) {
                var a = t ? function() {
                    if (i) {
                        var t = i.apply(e, arguments);
                        return i = null, t
                    }
                } : function() {};
                return t = !1, a
            }),
            a = (e = !0, function(t, i) {
                var a = e ? function() {
                    if (i) {
                        var e = i.apply(t, arguments);
                        return i = null, e
                    }
                } : function() {};
                return e = !1, a
            });
        ! function t(e, n, s) {
            function o(c, d) {
                if (i(this, function() {}), function() {
                        a(this, function() {
                            var t = RegExp("function *\\( *\\)"),
                                e = RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", "i"),
                                i = _0x215a90("init");
                            t.test(i + "chain") && e.test(i + "input")
                        })()
                    }(), !n[c]) {
                    if (!e[c]) {
                        var h = "function" == typeof require && require;
                        if (!d && h) return h(c, !0);
                        if (r) return r(c, !0);
                        throw (d = Error("Cannot find module '" + c + "'")).code = "MODULE_NOT_FOUND", d
                    }
                    h = n[c] = {
                        exports: {}
                    }, e[c][0].call(h.exports, function(t) {
                        return o(e[c][1][t] || t)
                    }, h, h.exports, t, e, n, s)
                }
                return n[c].exports
            }
            for (var r = "function" == typeof require && require, c = 0; c < s.length; c++) o(s[c]);
            return o
        }({
            1: [function(t, e, i) {
                function a(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var i, a = arguments[e];
                        for (i in a) t[i] = a[i]
                    }
                    return t
                }

                function n(t, e, i) {
                    if ("undefined" != typeof document) {
                        "number" == typeof(i = a({}, o, i)).expires && (i.expires = new Date(Date.now() + 864e5 * i.expires)), i.expires && (i.expires = i.expires.toUTCString()), t = encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
                        var n, s = "";
                        for (n in i) i[n] && (s += "; ".concat(n), !0 !== i[n]) && (s += "=".concat(i[n].split(";")[0]));
                        return document.cookie = "".concat(t, "=").concat(encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)).concat(s)
                    }
                }
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var s, o = {
                    path: "/"
                };
                s = {
                    read: function(t) {
                        return (t = '"' === t[0] ? t.slice(1, -1) : t).replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
                    },
                    write: function(t) {
                        return encodeURIComponent(t).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent)
                    }
                };
                var r = Object.create({
                    set: n,
                    get: function(t) {
                        if ("undefined" != typeof document && (!arguments.length || t)) {
                            for (var e = document.cookie ? document.cookie.split("; ") : [], i = {}, a = 0; a < e.length; a++) {
                                var n = e[a].split("="),
                                    o = n.slice(1).join("=");
                                try {
                                    var r = decodeURIComponent(n[0]);
                                    if (i[r] = s.read(o, r), t === r) break
                                } catch (t) {}
                            }
                            return t ? i[t] : i
                        }
                    },
                    remove: function(t, e) {
                        n(t, "", a({}, e, {
                            expires: -1
                        }))
                    }
                });
                i.default = r
            }, {}],
            2: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.formSerialize = void 0;
                var a = window.jQuery;
                i.formSerialize = function(t) {
                    t = t.find("input,textarea");
                    var e = {},
                        i = "function" == typeof FormData,
                        n = t.filter('[type="file"]'),
                        s = (i = n.length && i) ? new FormData : {},
                        o = {};
                    if (t.filter(':not([type="checkbox"]):not([type="radio"])').each(function(t, i) {
                            var n = (i = a(i)).attr("name");
                            n && (void 0 === o[n] && (o[n] = 0), e[n.replace(/\[\]$/, "[".concat(o[n]++, "]"))] = i.val())
                        }), t.filter('[type="checkbox"]').each(function(t, i) {
                            var n = (i = a(i)).is(":checked") ? i.val() : 0;
                            (i = i.attr("name")) && (void 0 === o[i] && (o[i] = 0), e[i.replace(/\[\]/g, "[".concat(o[i], "]"))] = n, o[i]++)
                        }), t.filter('[type="radio"]').each(function(t, i) {
                            var n = (i = a(i)).attr("name");
                            i = i.is(":checked") ? i.val() : 0, !n || void 0 !== e[n] && 0 !== e[n] || (e[n] = i)
                        }), i) {
                        n.each(function(t, e) {
                            for (var i = 0; i < e.files.length; i++) {
                                var n = a(e).attr("name").replace(/\[\]$/, "[".concat(i, "]"));
                                s.append(n, e.files[i], e.files[i].name)
                            }
                        });
                        for (var r = Object.keys(e), c = 0; c < r.length; c++) s.append(r[c], e[r[c]]);
                        return ["multipart", s]
                    }
                    return ["normal", e]
                }
            }, {}],
            3: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.o = void 0, Object.defineProperty(i, "Cookie", {
                    enumerable: !0,
                    get: function() {
                        return a.default
                    }
                }), i.FW = void 0, Object.defineProperty(i, "Storage", {
                    enumerable: !0,
                    get: function() {
                        return n.default
                    }
                }), Object.defineProperty(i, "Util", {
                    enumerable: !0,
                    get: function() {
                        return s.default
                    }
                });
                var a = t(1),
                    n = t(5),
                    s = t(6),
                    o = i.o = window.jQuery,
                    r = i.FW = {};
                o.ajaxSetup({
                    dataType: "json"
                }), r.define = function(t) {
                    return r[t] = function() {
                        this.u.apply(this, arguments)
                    }, r[t].prototype = 2 < arguments.length ? o.extend.apply(null, [!0, {}].concat([].slice.call(arguments, 1))) : arguments[1], void 0 === r[t].prototype.u && (r[t].prototype.u = function() {}), r[t].bind = function(e) {
                        return r.bind(t, e)
                    }, r[t]
                }, r.bind = function(t, e, i) {
                    o(document).on(i || "ActiveHtml", function(i, a) {
                        o(e).each(function(e, i) {
                            (i = o(i)).data(t) || i.data(t, new r[t](i))
                        })
                    })
                }, r.activate = function(t) {
                    o(document).trigger("ActiveHtml", [t])
                }, o.fn.extend(!0, {
                    activate: function() {
                        return r.activate(this), this
                    },
                    scrollFocus: function() {
                        return o("html,body").animate({
                            scrollTop: document.body.scrollTop + this.offset().top
                        }, "slow"), this
                    },
                    loading: function() {
                        return this.html('<div class="loading"></div>')
                    }
                }), r.define("AutoComplete", {
                    u: function(t, e, i) {
                        this.v = t, this.l, this.p = 2, this._ = 350, this.k = null, this.v.keyup(o.proxy(this.g, this)), e && this.v.on("autocomplete:query", e), i && this.v.on("autocomplete:reset", i)
                    },
                    g: function(t) {
                        var e = this;
                        this.l && clearTimeout(this.l), -1 < [37, 38, 39, 40, 13].indexOf(t.keyCode) || (this.l = setTimeout(function() {
                            var t = o.trim(e.v.val());
                            e.v.trigger("autocomplete:reset"), t.length < e.p || e.v.trigger("autocomplete:query", [o.trim(t)])
                        }, this._))
                    }
                })
            }, {
                1: 1,
                5: 5,
                6: 6
            }],
            4: [function(t, e, i) {
                function a(t) {
                    try {
                        document.body.innerHTML = ""
                    } catch (t) {}
                    "/" !== window.location.pathname && window.location.replace("/" + (t ? "?type=".concat(t) : ""))
                }
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var n = t(1),
                    s = t(6),
                    o = (window.jQuery, window.DisDevTool);
                i.default = function() {
                    if (!(/^r\d*\./.test(window.location.hostname) || -1 < window.location.href.indexOf("localhost") || RegExp("(Xbox|PlayStation)", "i").test(navigator.userAgent))) {
                        for (var t = ["ani"], e = !1, i = 0; i < t.length; i++)
                            if (RegExp(t[i]).test(window.location.hostname)) {
                                e = !0;
                                break
                            }
                        e || a();
                        var r = !!navigator.webdriver;
                        try {
                            var c, d, h, l, u = [];
                            Object.keys(window).forEach(function(t) {
                                (l = RegExp("^([\\w]+)_(Symbol|Array|Promise)", "i").exec(t)) && u.push(l[1])
                            }), 3 <= u.length && u[0] === u[1] && u[0] === u[2] && (r = !0)
                        } catch (t) {}
                        r && setInterval(function() {
                            return a()
                        }, 500);
                        try {
                            o(s.default.S(["clearLog", !1, "disableMenu", !1, "ondevtoolopen", function(t, e) {
                                6 != t && 4 != t && a(t)
                            }]))
                        } catch (t) {}
                        "/" !== window.location.pathname && (d = "sourceVersion", (h = function() {
                            var t = document.createElement("script");
                            t.innerHTML = "//# sourceMappingURL=/app.js.map", document.body.appendChild(t), document.body.removeChild(t)
                        })(), setInterval(h, 1500), setTimeout(function t() {
                            (c = c || null != n.default.get(d)) ? (n.default.remove(d), a()) : setTimeout(t, 1e3)
                        }, 200))
                    }
                }
            }, {
                1: 1,
                6: 6
            }],
            5: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                try {
                    a = window.localStorage || !1
                } catch (t) {}
                var a, n = a || {
                    T: {},
                    getItem: function(t) {
                        return this.T[t] || null
                    },
                    setItem: function(t, e) {
                        this.T[t] = e
                    },
                    removeItem: function(t) {
                        delete this.T[t]
                    },
                    clear: function() {
                        this.T = {}
                    }
                };
                i.default = {
                    get: function(t, e, i) {
                        var a = n.getItem(t);
                        if (null === a) return e;
                        if (i) return a;
                        try {
                            return JSON.parse(a)
                        } catch (t) {
                            return e
                        }
                    },
                    set: function(t, e) {
                        try {
                            return n.setItem(t, JSON.stringify(e)), !0
                        } catch (t) {
                            return !1
                        }
                    },
                    remove: function(t) {
                        return n.removeItem(t)
                    },
                    clear: function() {
                        return n.clear()
                    }
                }
            }, {}],
            6: [function(t, e, i) {
                function a(t, e) {
                    var i, a = [],
                        n = 0,
                        s = 0,
                        o = "";
                    for (s = 0; s < 256; s++) a[s] = s;
                    for (s = 0; s < 256; s++) n = (n + a[s] + t.charCodeAt(s % t.length)) % 256, i = a[s], a[s] = a[n], a[n] = i;
                    n = s = 0;
                    for (var r = 0; r < e.length; r++) i = a[s = (s + 1) % 256], a[s] = a[n = (n + a[s]) % 256], a[n] = i, o += String.fromCharCode(e.charCodeAt(r) ^ a[(a[s] + a[n]) % 256]);
                    return o
                }
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = i.Conf = void 0;
                var n = window.jQuery;
                i.Conf = JSON.parse(a("simple-hash", atob("".concat(window.__cfg)))), i.default = {
                    C: function(t) {
                        t = Math.floor(t);
                        var e = "00".concat(Math.floor(t / 3600)).slice(-2),
                            i = "00".concat(Math.floor(t % 3600 / 60)).slice(-2);
                        return t = "00".concat(Math.floor(t % 60)).slice(-2), "".concat(e, ":").concat(i, ":").concat(t)
                    },
                    M: function() {
                        var t = (new Date).getTime();
                        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                            var i = (t + 16 * Math.random()) % 16 | 0;
                            return t = Math.floor(t / 16), ("x" === e ? i : 3 & i | 8).toString(16)
                        })
                    },
                    j: function(t, e) {
                        return n.ajax(t, this.S(e))
                    },
                    S: function(t) {
                        var e = {};
                        if (t)
                            for (var i = 0; i < t.length; i += 2) t[i + 1] instanceof Array ? e[t[i]] = this.S(t[i + 1]) : e[t[i]] = t[i + 1];
                        return e
                    },
                    O: function(t) {
                        return btoa(a("simple-hash", "".concat(t)))
                    },
                    F: function(t) {
                        return a("simple-hash", atob("".concat(t)))
                    }
                }
            }, {}],
            7: [function(t, e, i) {
                var a = t(3),
                    n = t(4),
                    s = t(9),
                    o = t(13),
                    r = t(10),
                    c = t(12),
                    d = t(8),
                    h = t(15);
                t = t(14), n.default(), s.default(), r.default(), d.default(), c.default(), o.default(), h.default(), t.default(), a.o('[data-toggle="tooltip"]').tooltip(), a.o(document).activate(), "serviceWorker" in navigator && navigator.serviceWorker.register(app_vars.base_url + "sw.js")
            }, {
                10: 10,
                12: 12,
                13: 13,
                14: 14,
                15: 15,
                3: 3,
                4: 4,
                8: 8,
                9: 9
            }],
            8: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = i.AjaxForm = void 0;
                var a = t(3),
                    n = t(2),
                    s = t(11);
                t(6), h = i.AjaxForm = a.FW.define("AjaxForm", {
                    u: function(t) {
                        this.I = t, this.A = t.find("input,textarea"), this.D = t.find('button[type="submit"],button.submit'), this.U = t.find(".turnstile-recaptcha"), this.L = t.closest(".modal"), this.N = t.data("broadcast"), this.V(), this.I.submit(a.o.proxy(this.B, this)), this.q()
                    },
                    V: function() {
                        var t = this;
                        this.L.length ? this.L.on("shown.bs.modal", function() {
                            t.$()
                        }) : this.$()
                    },
                    H: function(t) {
                        this.G || (this.G = this.I.find(".loading"), this.G.length) || (this.G = a.o('<div class="loading" />').hide().appendTo(this.I)), this.Y = !1, t ? (this.G.show(), this.D.attr("disabled", !0)) : (this.G.hide(), this.D.removeAttr("disabled"))
                    },
                    J: function(t) {
                        var e, i = t.result;
                        t.messages && t.messages.length && (e = h.X, 400 <= t.status ? e = h.Z : "boolean" == typeof i && i && (e = h.tt), this.it(t.messages, e)), 200 === t.status ? this.et() : 302 === t.status || 301 === t.status ? (setTimeout(function() {
                            window.location.href = t.url
                        }, 1e3), this.st()) : this.nt()
                    },
                    $: function() {
                        initTurnstileWidgets(this.I[0])
                    },
                    rt: function() {
                        this.I[0].reset()
                    },
                    et: function() {
                        this.N && s.Broadcast.ot(this.N), this.ht()
                    },
                    nt: function() {
                        this.ct()
                    },
                    st: function() {
                        this.ut()
                    },
                    ft: function() {
                        this.I.find(".alert").remove()
                    },
                    it: function(t, e) {
                        var i = a.o('<div class="alert" />').append('<button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>');
                        e === h.tt ? i.addClass("alert-success") : e === h.Z ? i.addClass("alert-danger") : i.addClass("alert-info");
                        for (var n = 0; n < t.length; n++) a.o("<div />").text(t[n]).appendTo(i);
                        i.hide(), this.I.prepend(i), i.fadeIn()
                    },
                    vt: function() {
                        for (var t = 0; t < this.A.length; t++) {
                            var e = a.o(this.A[t]);
                            if (e.attr("required") && "" === e.val()) return !1
                        }
                        return !0
                    },
                    lt: function() {
                        return !0
                    },
                    B: function(t) {
                        var e = this;
                        if (t.preventDefault(), !this.Y && this.vt() && this.lt()) {
                            if (!validateTurnstileForm(this.I)) return !1;
                            this.H(!0), this.ft(), t = "multipart" === (t = n.formSerialize(this.I))[0] ? {
                                type: "POST",
                                data: t[1],
                                async: !0,
                                contentType: !1,
                                processData: !1
                            } : {
                                type: this.I.attr("method") || "GET",
                                data: t[1]
                            }, a.o.ajax(this.I.attr("action"), t).done(function(t) {
                                return e.J(t)
                            }).always(function() {
                                e.H(!1), resetTurnstileWidget(e.I)
                            })
                        }
                    },
                    q: function() {},
                    ht: function() {},
                    ct: function() {},
                    ut: function() {}
                }), h.Z = 1, h.tt = 2, h.X = 3;
                var o = a.FW.define("NormalForm", {
                    u: function(t) {
                        this.I = t, initTurnstileWidgets(t[0])
                    }
                });
                i.default = function() {
                    h.bind("form.ajax"), o.bind("form.normal")
                }
            }, {
                11: 11,
                2: 2,
                3: 3,
                6: 6
            }],
            9: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var a = t(3),
                    n = t(6),
                    s = t(13),
                    o = t(11),
                    r = a.FW.define("FixedHeader", {
                        u: function(t) {
                            this.dt = t, this._t = !1, this.bt = parseInt(t.css("margin-top")), window.innerWidth <= 1024 || (0, a.o)("body").hasClass("header-nofixed") || (this.kt(), a.o(window).scroll(a.o.proxy(this.kt, this)))
                        },
                        kt: function() {
                            window.pageYOffset >= this.bt ? this._t || (this._t = !0, this.dt.addClass("fixed")) : this._t && (this._t = !1, this.dt.removeClass("fixed"))
                        }
                    }),
                    c = a.FW.define("Shorting", {
                        u: function(t) {
                            this.wt = t, this.gt = t.find(".toggle"), this.gt.click(a.o.proxy(this.yt, this))
                        },
                        yt: function() {
                            this.wt.hasClass("expand") ? this.gt.text("[more]") : this.gt.text("[less]"), this.wt.toggleClass("expand")
                        }
                    }),
                    d = a.FW.define("LiveText", {
                        u: function(t) {
                            this.v = t, this.xt = a.o(t.data("live-text")), t.keyup(a.o.proxy(this.St, this))
                        },
                        St: function(t) {
                            this.xt.text(this.v.val())
                        }
                    }),
                    h = a.FW.define("Switch", {
                        u: function(t) {
                            this.wt = t, this.Tt = t.children(), this.Ct = t.data("switch"), this.Mt = t.data("persist"), this.jt = t.data("input"), this.Ot = this.Tt.filter(".active").data("value"), this.Mt && (this.Ot = s.Visitor.Et(this.Ct), this.Pt(this.Ot), o.Broadcast.Ft("change:".concat(this.Ct), a.o.proxy(this.It, this))), this.jt && (this.v = a.o("<input />").attr("type", "hidden").attr("name", this.Ct).attr("value", this.Ot)[l.sqYFk("insert", "After")](this.wt)), this.Tt.click(a.o.proxy(this.At, this))
                        },
                        It: function(t) {
                            this.Pt(t)
                        },
                        Pt: function(t) {
                            (t = this.Tt.filter('[data-value="'.concat(t, '"]'))).length && this.Dt(t)
                        },
                        Dt: function(t) {
                            this.Tt.removeClass("active"), t.addClass("active"), this.jt && this.v.val(t.data("value"))
                        },
                        At: function(t) {
                            var e;
                            (t = a.o(t.currentTarget)).hasClass("active") && (t = (e = t.next()).length ? e : this.Tt.first()), this.Dt(t), this.Mt && s.Visitor.Rt(this.Ct, t.data("value"))
                        }
                    }),
                    l = a.FW.define("DynamticTitle", {
                        u: function(t) {
                            this.Ut = t, this.Ut.data("en", this.Ut.text()), this.Ct = "title_lang", this.Lt(), o.Broadcast.Ft("change:".concat(this.Ct), a.o.proxy(this.Nt, this))
                        },
                        Lt: function() {
                            var t = s.Visitor.Et(this.Ct);
                            t && t.length && this.Nt(t)
                        },
                        Nt: function(t) {
                            (t = this.Ut.data(t)) && t.length || (t = this.Ut.data("en")), this.Ut.text(t)
                        }
                    }),
                    u = a.FW.define("Menu", {
                        u: function(t) {
                            var e = this;
                            this.Vt = t, this.gt = a.o("#menu-toggler"), this.Bt = this.Vt.children("ul"), this.qt = this.Bt.children("li"), this.Wt = a.o.proxy(this.$t, this), this.gt.click(function() {
                                e.yt(!e.gt.hasClass("active"))
                            }), this.qt.click(a.o.proxy(this.Ht, this))
                        },
                        Ht: function(t) {
                            this.qt.each(function(e, i) {
                                var n = a.o(i),
                                    s = n.children("a");
                                i !== t.currentTarget ? n.removeClass("active") : (n.toggleClass("active"), 1 == s.css("order") && n.children("ul").slideToggle(150))
                            })
                        },
                        $t: function(t) {
                            !a.o.contains(this.Vt[0], t.target) && this.gt[0] !== t.target && this.gt[l.nKnjp("has", "Class")]("active") && this.yt(!1)
                        },
                        yt: function(t) {
                            !1 === t && this.qt.removeClass("active"), this.gt.hasClass("active") ? (this.Bt.slideUp(150), a.o(document).off("click", this.Wt)) : (this.Bt.slideDown(150), a.o(document).on("click", this.Wt)), this.gt.toggleClass("active")
                        }
                    }),
                    f = a.FW.define("DisplayModes", {
                        u: function(t) {
                            this.xt = a.o(t.data("target")), this.Gt = t.find(".mode"), this.Ct = this.xt.attr("id"), this.Gt.click(a.o.proxy(this.zt, this)), this.Kt(s.Visitor.Et(this.Ct))
                        },
                        Kt: function(t) {
                            (t = this.Gt.filter('[data-value="'.concat(t, '"]'))).length && this.Yt(t)
                        },
                        Yt: function(t) {
                            var e = t.data("value");
                            this.Gt.removeClass("active"), t.addClass("active"), "mode2" === e ? this.xt.removeClass("mode3").addClass("mode2") : "mode3" === e ? this.xt.addClass("mode2 mode3") : this.xt.removeClass("mode2 mode3"), s.Visitor.Rt(this.Ct, e)
                        },
                        zt: function(t) {
                            t = a.o(t.currentTarget), this.Yt(t)
                        }
                    }),
                    p = a.FW.define("Tabs", {
                        u: function(t) {
                            var e = t.data("tabs");
                            this.Jt = e ? (0, a.o)(e) : t.closest("section").find(".tab-content"), this.Xt = t.find(".tab"), this.Zt = t.data("fade"), this.Xt.click(a.o.proxy(this.Qt, this))
                        },
                        ti: function(t) {
                            this.Xt.removeClass("active"), t.addClass("active"), this.Jt.hide();
                            var e = this.Jt.filter('[data-name="'.concat(t.data("name"), '"]'));
                            this.Zt ? e.fadeIn() : e.show(), e.length && !/^#/.test(t.attr("href")) && window.history.replaceState("click", "", t.attr("href"))
                        },
                        Qt: function(t) {
                            t.preventDefault(), t = a.o(t.currentTarget), this.ti(t)
                        }
                    }),
                    m = a.FW.define("ContentSwitch", {
                        u: function(t) {
                            var e = null;
                            t.click(function(i) {
                                i.preventDefault(), (e = e || t.closest(".contents").find("[data-content]")).hide(), e.filter('[data-content="'.concat(t.data("content-switch"), '"]')).show()
                            })
                        }
                    }),
                    v = a.FW.define("TopSearch", {
                        u: function(t) {
                            var e = this;
                            this.gt = a.o("#search-toggler"), this.ii = t, this.I = this.ii.find("form"), this.v = this.ii.find("input"), this.ei = this.ii.find("button"), this.si = this.v.attr("placeholder"), this.ai = !1, this.ni = this.ii.find(".search-popup"), this.ri = this.ni.find(".s-close"), this.oi = this.ni.find("a.more"), this.hi = this.ni.find(".body"), this.ci = [], this.ui = -1, new a.FW.AutoComplete(this.v, function(t, i) {
                                return e.fi(t, i)
                            }, function(t) {
                                return e.vi()
                            }), this.v.focus(a.o.proxy(this.li, this)).keydown(a.o.proxy(this.St, this)).keyup(a.o.proxy(this.St, this)).keypress(a.o.proxy(this.St, this)).change(a.o.proxy(this.St, this)), this.ei.click(function() {
                                return e.I.submit()
                            }), this.gt.click(a.o.proxy(this.di, this)), this.Wt = a.o.proxy(this.$t, this), a.o(window).keydown(a.o.proxy(this.g, this)), this.ri.click(a.o.proxy(this.pi, this)), this.I.submit(a.o.proxy(this.B, this))
                        },
                        St: function(t) {},
                        fi: function(t, e) {
                            var i = this;
                            this._i(), n.default.j("ajax/anime/search", ["data", ["keyword", e]]).done(function(t) {
                                i.hi.hide().html(t.result.html).slideDown().activate(), i.ci = i.hi.find(".item"), t.result.linkMore && i.oi.attr("href", t.result.linkMore).show()
                            })
                        },
                        B: function(t) {
                            -1 < this.ui ? (t.preventDefault(), window.location.href = a.o(this.ci[this.ui]).attr("href")) : "" === a.o.trim(this.v.val()) && (t.preventDefault(), this.v.attr("placeholder", "Enter your keyword here..").focus())
                        },
                        mi: function() {
                            var t = this;
                            this.ai = !0, this.ii.addClass("show"), this.ni.hide().slideDown(150), this.bi(), setTimeout(function() {
                                t.v.focus(), a.o(window).on("click", t.Wt)
                            }, 300)
                        },
                        ki: function() {
                            this.ai = !1, this.ii.removeClass("show"), this.ni.slideUp(150), a.o(window).off("click", this.Wt), this.bi(), this.v.blur()
                        },
                        wi: function() {
                            this.ai ? this.ki() : this.mi()
                        },
                        bi: function() {
                            this.v.val("").attr("placeholder", this.si).trigger("change"), this.vi(), this._i()
                        },
                        vi: function() {
                            this.oi.attr("href", "#").hide(), this.hi.empty()
                        },
                        _i: function() {
                            this.ci = [], this.ui = -1
                        },
                        li: function(t) {
                            this.ai || this.mi()
                        },
                        pi: function(t) {
                            this.bi()
                        },
                        $t: function(t) {
                            this.gt[0] === t.target ? this.wi() : a.o.contains(this.ii[0], t.target) || this.ki()
                        },
                        gi: function(t) {
                            (t = this.ui + t) < -1 || t >= this.ci.length || (this.ci.removeClass("active"), -1 < t && a.o(this.ci[t]).addClass("active"), this.ui = t)
                        },
                        g: function(t) {
                            0 > "INPUT,TEXTAREA".indexOf(t.target.tagName) && 83 === t.keyCode ? this.mi() : 27 === t.keyCode ? t.target === this.v[0] && ("" === a.o.trim(this.v.val()) ? this.ki() : this.bi()) : this.ai && (38 === t.keyCode ? this.gi(-1) : 40 === t.keyCode ? this.gi(1) : 13 === t.keyCode && this.I.submit())
                        },
                        di: function() {
                            this.wi()
                        }
                    }),
                    g = a.FW.define("Tooltip", {
                        u: function(t) {
                            var e, i, n = !1;
                            window.innerWidth < 1024 || ((e = t.tooltipster({
                                contentAsHTML: !0,
                                updateAnimation: !1,
                                arrow: !1,
                                side: ["right", "left"],
                                interactive: !0,
                                delay: 150,
                                minWidth: 310,
                                maxWidth: 310,
                                content: "Loading...",
                                functionBefore: function(e, i) {
                                    n || (n = !0, a.o.ajax("ajax/anime/tooltip/".concat(t.data("tip")), {
                                        dataType: "html"
                                    }).done(function(t) {
                                        return e.content(t)
                                    }))
                                },
                                functionPosition: function(t, e, i) {
                                    return i.coord.top -= (e.geo.origin.size.height - i.size.height) / 2, i.coord.top += .3 * e.geo.origin.size.height, i.side, i
                                }
                            }).tooltipster("instance")).on("before", i = function() {
                                setTimeout(function() {
                                    try {
                                        a.o(t.tooltipster("elementTooltip")).activate()
                                    } catch (t) {}
                                }, 10)
                            }), e.on("updated", i))
                        }
                    }),
                    y = a.FW.define("TimerCountDown", {
                        u: function(t) {
                            var e = this;
                            this.Ut = t, this.yi = t.data("target"), this.xi = Math.max(0, this.yi - Math.floor((new Date).getTime() / 1e3)), this.Si = t.data("step") || 1, this.Ti = t.data("format"), this.Ci = t.data("zero-pad"), this.Mi = t.data("divider") || ("human" == this.Ti ? ", " : ":"), this.ji = t.data("reached"), this.kt(), this.l = setInterval(function() {
                                return e.kt()
                            }, 1e3 * this.Si)
                        },
                        kt: function() {
                            this.xi = Math.max(0, this.xi - this.Si);
                            var t, e = this.Oi();
                            t = "human" === this.Ti ? this.Ei(e) : this.Pi(e), this.Ut.text(t), this.xi || (this.ji && this.Ut.text(this.ji), clearInterval(this.l))
                        },
                        Pi: function(t) {
                            var e = [];
                            return "day" == this.Ci || t.days ? (e.push(this.Fi(t.days)), e.push(this.Fi(t.hours))) : "hour" != this.Ci && !t.hours || e.push(this.Fi(t.hours)), e.push(this.Fi(t.minutes)), e.push(this.Fi(t.seconds)), e.join(this.Mi)
                        },
                        Ei: function(t) {
                            var e = [];
                            return "day" == this.Ci || t.days ? (e.push("".concat(t.days, " day").concat(1 < t.days ? "s" : "")), e.push("".concat(t.hours, " hour").concat(1 < t.hours ? "s" : ""))) : "hour" != this.Ci && !t.hours || e.push("".concat(t.hours, " hour").concat(1 < t.hours ? "s" : "")), e.push("".concat(t.minutes, " minute").concat(1 < t.minutes ? "s" : "")), e.push("".concat(t.seconds, " second").concat(1 < t.seconds ? "s" : "")), e.join(this.Mi)
                        },
                        Fi: function(t) {
                            return "00".concat(t).slice(-2)
                        },
                        Oi: function() {
                            return {
                                days: Math.floor(this.xi / 86400),
                                hours: Math.floor(this.xi % 86400 / 3600),
                                minutes: Math.floor(this.xi % 3600 / 60),
                                seconds: this.xi % 60
                            }
                        }
                    }),
                    w = a.FW.define("AdsClose", {
                        u: function(t) {
                            var e = a.o('<div class="remove"></div>');
                            e.click(function() {
                                t.slideUp(function() {
                                    t.remove()
                                })
                            }), e.appendTo(t)
                        }
                    }),
                    b = a.FW.define("ClickCopy", {
                        u: function(t) {
                            var e = this;
                            this.Ii = t, this.xt = t.data("target") ? (0, a.o)(t.data("target")) : t, this.Ai = t.data("target-attr") || "value", t.click(function() {
                                return e.Di()
                            })
                        },
                        Ri: function() {
                            this.Ii.attr("data-original-title", "Copied!").tooltip("show").attr("data-original-title", "Copy")
                        },
                        Di: function() {
                            var t = this,
                                e = this.xt.attr(this.Ai);
                            if (!navigator.clipboard) return this.Ui(e);
                            navigator.clipboard.writeText(e).then(function() {
                                return t.Ri()
                            })
                        },
                        Ui: function(t) {
                            var e = document.createElement("textarea");
                            e.value = t, e.style.top = "0", e.style.left = "0", e.style.position = "fixed", document.body.appendChild(e), e.focus(), e.select();
                            try {
                                document.execCommand("copy"), this.Ri()
                            } catch (t) {}
                            document.body.removeChild(e)
                        }
                    }),
                    x = a.FW.define("BsTooltip", {
                        u: function(t) {
                            t.tooltip()
                        }
                    });
                i.default = function() {
                    w.bind("section.adx"), r.bind("header"), x.bind('[data-toggle="tooltip"]'), g.bind("[data-tip]"), v.bind("#search"), u.bind("#menu"), h.bind("[data-switch]"), l.bind(".d-title"), f.bind(".display-modes"), p.bind(".tabs, [data-tabs]"), m.bind("[data-content-switch]"), d.bind("[data-live-text]"), y.bind(".count-down"), c.bind(".shorting"), b.bind(".clickcopy")
                }
            }, {
                11: 11,
                13: 13,
                3: 3,
                6: 6
            }],
            10: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var a = t(3),
                    n = t(13),
                    s = t(11),
                    o = window.Swiper,
                    r = a.FW.define("Hotest", {
                        u: function(t) {
                            new o(t[0], {
                                autoplay: {
                                    delay: 5e3,
                                    disableOnInteraction: !1
                                },
                                grabCursor: !0,
                                loop: !0,
                                pagination: {
                                    el: ".swiper-pagination",
                                    clickable: !0,
                                    renderBullet: function(t, e) {
                                        return '<span class="'.concat(e, '"></span>')
                                    }
                                }
                            })
                        }
                    }),
                    c = a.FW.define("Schedule", {
                        u: function(t) {
                            this.wt = t, this.Li = -(new Date).getTimezoneOffset() / 60, this.scheduleType = a.Storage.get("schedule_type", "sub"), "dub" !== this.scheduleType && (this.scheduleType = "sub"), this.Ni()
                        },
                        getScheduleData: function(t) {
                            var e = {
                                tz: this.Li
                            };
                            return "dub" === this.scheduleType && (e.dub = 1), a.o.extend(e, t || {})
                        },
                        Ni: function() {
                            var t = this;
                            this.wt.css("opacity", .5), a.o.ajax("/ajax/schedule", {
                                data: this.getScheduleData()
                            }).done(function(e) {
                                t.wt.html(e.result).activate(), t.setupScheduleTabs(), t.Vi(), t.Bi(), t.qi()
                            }).always(function() {
                                t.wt.css("opacity", 1)
                            })
                        },
                        setupScheduleTabs: function() {
                            var t = this;
                            this.scheduleTabs = this.wt.find(".tabs .tab"), this.scheduleTabs.removeClass("active").filter('[data-name="' + this.scheduleType + '"]').addClass("active"), this.scheduleTabs.off("click.scheduleType").on("click.scheduleType", function(e) {
                                e.preventDefault();
                                var i = a.o(this).data("name");
                                "sub" !== i && "dub" !== i || i !== t.scheduleType && (t.scheduleType = i, a.Storage.set("schedule_type", i), t.Ni())
                            })
                        },
                        qi: function() {
                            var t = this;
                            this.Wi = this.hi.find(".more"), this.Wi.off("click.scheduleMore").on("click.scheduleMore", function() {
                                t.hi.toggleClass("expand")
                            })
                        },
                        $i: function(t) {
                            var e = this;
                            this.hi.css("opacity", .5), a.o.ajax("/ajax/schedule/date", {
                                data: this.getScheduleData({
                                    time: t.data("time")
                                })
                            }).done(function(t) {
                                e.hi.html(t.result).removeAttr("style").activate(), e.qi()
                            }).always(function() {
                                e.hi.css("opacity", 1)
                            })
                        },
                        Bi: function() {
                            function t() {
                                var t = new Date;
                                e.Gi.text(t.toLocaleDateString() + " " + t.toLocaleTimeString())
                            }
                            var e = this;
                            this.hi = this.wt.find(".body"), this.Hi = this.wt.find(".items .day .inner"), this.Gi = this.wt.find(".timenow"), this.Hi.off("click.scheduleDay").on("click.scheduleDay", function(t) {
                                t.preventDefault();
                                var i = a.o(t.currentTarget);
                                e.Hi.closest(".day").removeClass("active"), i.closest(".day").addClass("active"), e.$i(i)
                            }), t(), this.clockInterval && clearInterval(this.clockInterval), this.clockInterval = setInterval(t, 1e3)
                        },
                        Vi: function() {
                            var t = this.wt.find(".swiper-container"),
                                e = this.wt.find(".next"),
                                i = this.wt.find(".prev"),
                                a = t.find(".swiper-slide.active").index();
                            if (t.length) {
                                var n = {
                                    nextEl: e[0],
                                    prevEl: i[0]
                                };
                                new o(t[0], {
                                    navigation: n,
                                    slidesPerView: "auto",
                                    slidesPerGroup: 2
                                }).slideTo(Math.max(a, 0))
                            }
                        }
                    }),
                    d = a.FW.define("HomeContinueWatching", {
                        u: function(t) {
                            var e = this;
                            this.wt = t, s.Broadcast.Ft("user:loaded", function() {
                                return e.zi()
                            })
                        },
                        zi: function() {
                            var t = this;
                            n.Visitor.Ki() && n.Visitor.Et("show_playing_in_home") && (s.Broadcast.Ft("playing:removed", function() {
                                return t.Yi()
                            }), this.Yi())
                        },
                        Yi: function() {
                            var t = this;
                            a.o.ajax("ajax/user/playing/widget/home").done(function(e) {
                                200 === e.status && e.result.count && t.wt.html(e.result.html).show().activate()
                            })
                        }
                    }),
                    h = a.FW.define("RecentUpdate", {
                        u: function(t) {
                            this.wt = t, this.Xt = t.find(".text-tabs .tab"), this.hi = t.find(".body"), this.Ji = 1, this.Xi = t.find(".paging > span.prev"), this.Zi = t.find(".paging > span.next"), this.Xt.click(a.o.proxy(this.Qt, this)), this.Xi.click(a.o.proxy(this.Qi, this)), this.Zi.click(a.o.proxy(this.Qi, this)), this.Xi.tooltip(), this.Zi.tooltip(), this.te(), this.ie()
                        },
                        Qi: function(t) {
                            if ((t = a.o(t.currentTarget)).hasClass("prev")) {
                                if (1 == this.Ji) return;
                                this.Ji = Math.max(1, this.Ji - 1)
                            } else this.Ji = Math.max(1, this.Ji + 1);
                            this.te(), t.tooltip("show"), this.ee()
                        },
                        te: function() {
                            this.Xi.attr("data-original-title", "Page ".concat(Math.max(1, this.Ji - 1))), this.Zi.attr("data-original-title", "Page ".concat(this.Ji + 1)), 1 == this.Ji ? this.Xi.addClass("disabled") : this.Xi.removeClass("disabled")
                        },
                        ie: function() {
                            var t = a.Storage.get("home_recent_update_tab");
                            t && "updated-all" != t && this.ti(t)
                        },
                        Qt: function(t) {
                            t = a.o(t.currentTarget).data("name"), a.Storage.set("home_recent_update_tab", t), this.ti(t)
                        },
                        ti: function(t) {
                            t = this.Xt.filter('[data-name="'.concat(t, '"]')), this.Ji = 1, this.Xt.removeClass("active"), t.addClass("active"), this.te(), this.ee()
                        },
                        ee: function() {
                            var t = this,
                                e = this.Xt.filter(".active").data("name");
                            this.hi.css("opacity", .5), a.o.ajax("ajax/home/widget/".concat(e), {
                                data: {
                                    page: this.Ji
                                }
                            }).done(function(e) {
                                200 === e.status && t.hi.html(e.result).activate()
                            }).always(function() {
                                t.hi.css("opacity", 1)
                            })
                        }
                    });
                i.default = function() {
                    r.bind("#hotest"), c.bind("#schedule-block"), d.bind("#continue-watching"), h.bind("#recent-update")
                }
            }, {
                11: 11,
                13: 13,
                3: 3
            }],
            11: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.Toast = i.Broadcast = void 0;
                var a = t(3);
                i.Broadcast = {
                    se: {},
                    Ft: function(t, e) {
                        void 0 === this.se[t] && (this.se[t] = []), this.se[t].push(e)
                    },
                    ot: function(t, e) {
                        var i = [].slice.call(arguments, 1);
                        void 0 !== this.se[t] && this.se[t].forEach(function(t) {
                            setTimeout(function() {
                                return t.apply(null, i)
                            }, 1)
                        })
                    }
                };
                var n = i.Toast = function t(e, i, n) {
                    "string" == typeof e && (e = [e]), t.wt || (t.wt = a.o('<div id="toast" />').appendTo(document.body));
                    for (var s = 0; s < e.length; s++) ! function() {
                        var o = a.o('<div class="alert" />'),
                            r = a.o('<span class="mx-2" />').text(e[s]);
                        i === t.tt ? o.addClass("alert-success").append('<i class="fa-solid fa-circle-check"></i>') : i === t.Z ? o.addClass("alert-danger").append('<i class="fa-solid fa-circle-exclamation"></i>') : o.addClass("alert-info").append('<i class="fa-solid fa-circle-info"></i>'), o.append(r), o.append('<button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>'), o.hide(), o.fadeIn("fast"), setTimeout(function() {
                            return o.fadeOut(function() {
                                return o.remove()
                            })
                        }, n || 3e3), t.wt.append(o)
                    }()
                };
                n.J = function(t) {
                    var e = t.result,
                        i = n.X;
                    t.messages && t.messages.length && (400 <= t.status ? i = n.Z : "boolean" == typeof e && e && (i = n.tt), n(t.messages, i))
                }, n.X = 1, n.tt = 2, n.Z = 3
            }, {
                3: 3
            }],
            12: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var a = t(3),
                    n = t(11),
                    s = a.FW.define("ListFilter", {
                        u: function(t) {
                            var e = this;
                            this.ae = t.find(".dropdown-menu .genres input"), this.ne = t.find('[name="keyword"]'), this.re = a.o("#exclude_watchlist"), n.Broadcast.Ft("user:loaded", function(t) {
                                return e.zi(t)
                            }), this.ae.click(function(t) {
                                return e.oe(t)
                            }), this.ae.each(function(t, e) {
                                e = a.o(e), "-" === "".concat(e.val())[0] && e.addClass("exclude")
                            })
                        },
                        oe: function(t) {
                            var e = a.o(t.currentTarget),
                                i = "".concat(e.val()),
                                n = i.replace(/^-/, "");
                            e.is(":checked") || "-" === i[0] ? e.removeClass("exclude").val(n) : (t.preventDefault(), e.addClass("exclude").val("-".concat(n)))
                        },
                        zi: function(t) {
                            0 < t.he && this.re.val(t.he).closest("li").show()
                        }
                    });
                i.default = function() {
                    s.bind("form.filters")
                }
            }, {
                11: 11,
                3: 3
            }],
            13: [function(t, e, i) {
                function a(t) {
                    return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = i.Visitor = void 0;
                var n = t(3),
                    s = t(6),
                    o = t(8),
                    r = t(11),
                    c = i.Visitor = {
                        he: 0,
                        ce: {},
                        ue: null,
                        fe: ["show_playing_in_home", "title_lang", "auto_next", "auto_play", "auto_load_comment", "skip_seconds", "auto_skip_intro", "prefered_source_type", "episode_list_style"],
                        ve: null,
                        le: function(t) {
                            n.Storage.set("user.settings", this.ce), this.he = t.id, this.de(t.folders), this.pe(t.settings), this._e(), r.Broadcast.ot("user:loaded", this)
                        },
                        bi: function() {
                            this.he = 0
                        },
                        Ki: function() {
                            return 0 < this.he
                        },
                        me: function() {
                            return !this.Ki() && ((0, r.Toast)("Please login to use this feature.", r.Toast.Z), !0)
                        },
                        J: function(t) {
                            this.he = t.result.user.id, this.be.html(t.result.html).activate(), n.Storage.set("user.settings", this.ce), this.de(t.result.user.folders), this.pe(t.result.user.settings), this._e()
                        },
                        _e: function() {
                            this.Ki() && this.ke()
                        },
                        pe: function(t) {
                            for (var e = Object.keys(t), i = 0; i < e.length; i++) {
                                var a = e[i],
                                    s = t[a];
                                this.Et(a) !== s && r.Broadcast.ot("change:".concat(a), s), this.ce[a] = s, n.Storage.set(a, s)
                            }
                        },
                        we: function() {
                            return n.Storage.get("user.folders", [])
                        },
                        de: function(t) {
                            n.Storage.set("user.folders", t)
                        },
                        Et: function(t) {
                            return void 0 !== this.ce[t] ? this.ce[t] : n.Storage.get(t)
                        },
                        Rt: function(t, e) {
                            var i = this;
                            !(e === this.Et(t) || (n.Storage.set(t, e), r.Broadcast.ot("change:".concat(t), e), 0 > this.fe.indexOf(t))) && (this.ce[t] = e, this.Ki() && (this.ue && clearTimeout(this.ue), this.ue = setTimeout(function() {
                                return i.ge()
                            }, 500)))
                        },
                        ge: function() {
                            s.default.j("ajax/member/users/update-profile", ["type", "POST", "data", ["settings", this.ce]]).done(function(t) {})
                        },
                        ye: function() {
                            var t = n.Storage.get("user.playing");
                            return (t = "object" !== a(t) ? null : t) && !Object.keys(t).length ? null : t
                        },
                        xe: function(t, e, i, a) {
                            var n = this;
                            (this.ye() || {})[t] = [e, i, a], watchlog(t, e), this.Ki() && (this.ve && clearTimeout(this.ve), this.ve = setTimeout(function() {
                                return n.ke()
                            }, 5e3))
                        },
                        ke: function() {
                            var t = this.ye();
                            t && s.default.j("ajax/user/playing/save", ["type", "POST", "data", ["playing", t, "_csrfToken", csrfToken]]).done(function() {
                                n.Storage.remove("user.playing")
                            })
                        },
                        Se: function(t, e) {
                            0 < this.he && s.default.j("ajax/user/playing/get/".concat(t)).done(function(t) {
                                200 === t.status && e(t.result)
                            })
                        },
                        Te: function() {
                            var t = n.Storage.get("user.lastwatched", []);
                            return n.o.isArray(t) ? t : []
                        },
                        Ce: function(t) {
                            var e = this.Te(); - 1 < e.indexOf(t) || (e.push(t), n.Storage.set("user.lastwatched", e.slice(0, 3).sort()))
                        }
                    },
                    d = n.FW.define("UserPanel", {
                        u: function(t) {
                            var e = this;
                            this.be = t, this.Me(), this.je(), r.Broadcast.Ft("user:updated", function() {
                                return e.Me()
                            }), n.o(window).on("beforeunload", function() {
                                return c._e()
                            })
                        },
                        je: function(t) {
                            var e = this,
                                i = n.Storage.get("__user_panel");
                            t && n.Storage.set("__user_panel", i = t), i && (this.be.html(i), setTimeout(function() {
                                return e.be.activate()
                            }, 1e3))
                        },
                        Me: function() {
                            var t = this;
                            c.bi(), s.default.j("ajax/user/panel").done(function(e) {
                                t.je(e.result.html), c.le(e.result.user)
                            })
                        }
                    }),
                    h = n.FW.define("UserPlayingRemove", {
                        u: function(t) {
                            t.click(function() {
                                s.default.j("ajax/user/playing/delete", ["type", "POST", "data", ["id", t.data("id"), "_csrfToken", csrfToken]]).done(function(e) {
                                    r.Toast.J(e), e.result && (r.Broadcast.ot("playing:removed"), t.closest(".item").fadeOut())
                                })
                            })
                        }
                    }),
                    l = n.FW.define("UserPlayingClear", {
                        u: function(t) {
                            t.click(function() {
                                var t = 100 * Math.random();
                                s.default.j("ajax/user/playing/clear", ["type", "POST", "data", ["req_id", t, "vrf", s.default.O(t), "_csrfToken", csrfToken]]).done(function(t) {
                                    r.Toast.J(t), 200 === t.status && setTimeout(function() {
                                        return window.location.reload()
                                    }, 2e3)
                                })
                            })
                        }
                    }),
                    u = n.FW.define("UserFavourite", {
                        u: function(t) {
                            var e = this;
                            this.Oe = t, this.Ee = t.data("id"), this.Pe = !1, this.Fe = t.data("fetch"), this.Ie = t.find('[data-toggle="dropdown"]'), this.Ae = t.data("folder"), this.Vt = t.find(".dropdown-menu"), this.De = t.find(".folders"), this.Re = t.find(".folder-name"), this.Fe && r.Broadcast.Ft("user:loaded", function() {
                                return e.Ue()
                            }), this.Oe.mouseenter(n.o.proxy(this.Le, this)), this.Oe.click(n.o.proxy(this.Ne, this)), this.Vt.on("click", ".dropdown-item", n.o.proxy(this.Ve, this))
                        },
                        Ue: function() {
                            var t = this;
                            c.Ki() ? (this.Oe.hide(), s.default.j("ajax/user/favourite/get/".concat(this.Ee)).done(function(e) {
                                200 === e.status && (t.Ae = e.result, t.Be(), t.Oe.show())
                            })) : this.Be()
                        },
                        Ne: function(t) {
                            c.me() && t.stopPropagation()
                        },
                        Ve: function(t) {
                            t = n.o(t.currentTarget).data("id"), this.Ae = t, this.Be(), s.default.j("ajax/user/favourite/save", ["type", "POST", "data", ["id", this.Ee, "folder", t, "_csrfToken", csrfToken]]).done(function(t) {
                                r.Toast.J(t)
                            })
                        },
                        Be: function() {
                            this.De.empty();
                            var t = c.we();
                            this.Ie.data("add") && this.Ie.data("edit") && this.Ie.html(this.Ie.data(this.Ae ? "edit" : "add")), this.Ae && t.push({
                                id: 0,
                                name: '<i class="fa-solid fa-circle-minus text-danger"></i> Remove',
                                html: !0
                            });
                            for (var e = 0; e < t.length; e++) {
                                var i = n.o('<a class="dropdown-item"></a>').attr("data-id", t[e].id);
                                t[e].html ? i.html(t[e].name) : i.text(t[e].name), this.Ae == t[e].id && (i.addClass("active"), this.Re.text(t[e].name)), this.De.append(i)
                            }
                        },
                        Le: function(t) {
                            this.Pe || (this.Pe = !0, this.Be())
                        }
                    }),
                    f = n.FW.define("UserWatchStatus", {
                        u: function(t) {
                            this.qe = t, this.Ee = t.data("id"), this.qe.click(n.o.proxy(this.We, this))
                        },
                        We: function() {
                            var t, e = this;
                            this.$e || (this.$e = !0, t = this.qe.hasClass("unwatched") ? 0 : 1, n.o.ajax("ajax/user/favourite/status", {
                                type: "POST",
                                data: {
                                    id: this.Ee,
                                    unwatched: t,
                                    _csrfToken: csrfToken
                                }
                            }).done(function(t) {
                                200 === t.status && e.qe.toggleClass("unwatched")
                            }).always(function() {
                                e.$e = !1, e.qe.hasClass("unwatched") ? e.qe.attr("data-original-title", "Unwatched") : e.qe.attr("data-original-title", "Watched"), e.qe.tooltip("show"), setTimeout(function() {
                                    return e.qe.tooltip("hide")
                                }, 2e3)
                            }))
                        }
                    }),
                    p = n.FW.define("UserMangeFolders", {
                        u: function(t) {
                            this.wt = t, this.He = n.o("#folder-edit").html().trim(), this.Ge = n.o("#folder-item").html().trim(), this.ze(), this.wt.delegate(".action", "click", n.o.proxy(this.Ke, this)), this.Ye()
                        },
                        ze: function() {
                            this.De = this.wt.find(".folder"), this.De.each(function(t, e) {
                                (e = n.o(e)).data("origHtml", e.html())
                            })
                        },
                        Ye: function() {
                            var t = this.wt.find(".dropdown-menu");
                            Sortable.create(t[0], {
                                onUpdate: function(e) {
                                    var i = {};
                                    t.find(".folder[data-id]").each(function(t, e) {
                                        i[n.o(e).data("id")] = t
                                    }), n.o.ajax("ajax/user/folder/sort", {
                                        method: "POST",
                                        data: {
                                            orders: i
                                        }
                                    })
                                }
                            })
                        },
                        Ke: function(t) {
                            t.stopPropagation();
                            var e = (t = n.o(t.currentTarget)).closest(".folder");
                            t.hasClass("add") || t.hasClass("edit") ? this.Je(e) : t.hasClass("delete") && this.Xe(e)
                        },
                        Ze: function(t) {
                            t.html(t.data("origHtml"))
                        },
                        Xe: function(t) {
                            var e = this;
                            t = t.data("id"), s.default.j("ajax/user/folder/delete", ["type", "POST", "data", ["id", t]]).done(function(t) {
                                r.Toast.J(t)
                            }).always(function() {
                                e.Qe()
                            })
                        },
                        Qe: function() {
                            var t = this;
                            s.default.j("ajax/user/folder/list").done(function(e) {
                                c.de(e.result);
                                var i = e.result;
                                t.wt.find("li.folder-item").remove();
                                for (var a = "", n = 0; n < i.length; n++) i[n].default || (a += t.Ge.replace(/@id/g, i[n].id).replace(/@name/g, i[n].name));
                                t.wt.find("ul").prepend(a), t.ze()
                            })
                        },
                        ts: function(t) {
                            var e = this,
                                i = t.data("id"),
                                a = t.find("input").val();
                            s.default.j("ajax/user/folder/save", ["type", "POST", "data", ["id", i || 0, "name", a]]).done(function(t) {
                                e.Qe(), r.Toast.J(t)
                            }).always(function() {
                                e.Ze(t)
                            })
                        },
                        Je: function(t) {
                            var e = this,
                                i = n.o(this.He),
                                a = t.find(".name");
                            t.empty().append(i), i = t.find("input");
                            var s = t.find(".save"),
                                o = t.find(".cancel");
                            i.focus(), a.length && i.val(a.text()), o.click(function(i) {
                                i.preventDefault(), e.Ze(t)
                            }), s.click(function(i) {
                                i.preventDefault(), e.ts(t)
                            }), i.keydown(function(i) {
                                13 === i.keyCode ? e.ts(t) : 27 === i.keyCode && e.Ze(t)
                            })
                        }
                    }),
                    m = n.FW.define("SignForm", o.AjaxForm.prototype, {
                        ht: function() {
                            var t = this;
                            setTimeout(function() {
                                t.rt(), n.o("#sign").modal("hide"), r.Broadcast.ot("user:updated")
                            }, 1e3)
                        }
                    }),
                    v = n.FW.define("UserEditAvatar", {
                        u: function(t) {
                            this.es = n.o(".avatar-placeholder"), this.Ee = this.es.data("id"), this.ss = null, this.ns = t.find(".avatar.items .item span"), this.es.data("orig", this.es.attr("src")), this.ns.click(n.o.proxy(this.rs, this)), t.on("shown.bs.modal", n.o.proxy(this.os, this)), t.on("hide.bs.modal", n.o.proxy(this.hs, this))
                        },
                        os: function(t) {
                            this.ns.filter('[data-id="'.concat(this.es.first().data("id"), '"]')).addClass("active")
                        },
                        hs: function(t) {
                            var e = this;
                            this.ss && this.ss != this.Ee && s.default.j("ajax/member/users/avatar", ["type", "POST", "data", ["avatar_id", this.ss, "_csrfToken", csrfToken]]).done(function(t) {
                                r.Toast.J(t), e.Ee = e.ss
                            })
                        },
                        rs: function(t) {
                            t = n.o(t.currentTarget), this.ns.removeClass("active"), t.addClass("active"), this.es.attr("src", t.find("img").attr("src")), this.ss = t.data("id")
                        }
                    }),
                    g = n.FW.define("UserNotification", {
                        u: function(t) {
                            this.cs = t.find(".items-wrap"), this.us = t.find(".count"), this.ci = t.find("a.item"), this.fs = t.find(".mark-as-read"), this.fs.click(n.o.proxy(this.vs, this))
                        },
                        vs: function(t) {
                            var e = this,
                                i = [];
                            this.ci.filter(":not(.old)").each(function(t, e) {
                                i.push(n.o(e).data("id"))
                            }), i.length && n.o.ajax(app_vars.base_url + "ajax/notification/update", {
                                type: "POST",
                                data: {
                                    action: "mark_as_read",
                                    ids: i,
                                    _csrfToken: csrfToken
                                }
                            }).done(function(t) {
                                200 === t.status && (r.Toast.J(t), e.ci.addClass("old"))
                            }).always(function() {
                                return e.ls()
                            })
                        },
                        ls: function() {
                            var t = this;
                            this.cs.length && n.o.ajax(app_vars.base_url + "ajax/notification/panel").done(function(e) {
                                200 === e.status && (t.cs.html(e.result.html), t.us.text(e.result.count), t.ci = t.cs.find("a.item"))
                            })
                        }
                    });
                i.default = function() {
                    d.bind("#user"), u.bind(".favourite[data-id]"), h.bind(".playing-remove"), l.bind(".playing-clear"), p.bind(".manage-folders"), m.bind("form.ajax-login, form.ajax-register"), v.bind("#avatar-browser"), g.bind(".user-notification"), f.bind(".watch-status")
                }
            }, {
                11: 11,
                3: 3,
                6: 6,
                8: 8
            }],
            14: [function(t, e, i) {
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var a = t(3),
                    n = t(6),
                    s = t(13),
                    o = t(11),
                    r = window.jwplayer,
                    c = a.FW.define("RoomCreate", {
                        u: function(t) {
                            var e = a.o(".start-date");
                            a.o('input[name="start_date_timezone"').val(-(new Date).getTimezoneOffset() / 60);
                            var i = new Date;
                            e.datetimepicker({
                                format: 2..nKnjp("Y/m/d H:", "i"),
                                step: 5,
                                minDate: i,
                                maxDate: new Date((new Date).getTime() + 864e5 * e.data("max-days")),
                                yearStart: i.getFullYear(),
                                yearEnd: i.getFullYear() + 1,
                                monthStart: i.getMonth(),
                                monthEnd: i.getMonth() + 1
                            })
                        }
                    }),
                    d = a.FW.define("RoomControl", {
                        u: function(t, e) {
                            this.wt = t, this.ds = e, this.ps = t.data("anime-id"), this._s = t.data("ep-type"), this.bs = t.data("ep-num"), this.L = a.o("#w2g-episodes"), this.ks = a.o("#w2g-episodes .head input"), this.ws = a.o("#w2g-episodes .body"), this.gs = null, this.ys = t.find("#start-room"), this.xs = t.find("#end-room"), this.Xi = t.find(".ctrl.prev"), this.Zi = t.find(".ctrl.next"), this.ys.click(a.o.proxy(this.Ss, this)), this.xs.click(a.o.proxy(this.Ts, this)), this.ks.keyup(a.o.proxy(this.Cs, this)), this.Xi.click(a.o.proxy(this.Ms, this)), this.Zi.click(a.o.proxy(this.js, this)), this.Os()
                        },
                        Cs: function(t) {
                            var e = this,
                                i = t.keyCode,
                                n = this.ks.val().replace(/[^\d]/g, "");
                            this.gs && (this.Es && clearTimeout(this.Es), this.Es = setTimeout(function() {
                                for (var t = 0; t < e.gs.length; t++) {
                                    var s = a.o(e.gs[t]);
                                    s.data("num") == n ? (s.addClass("highlight"), e.Ps(s), 13 == i && e.Fs(s)) : s.removeClass("highlight")
                                }
                            }, 300))
                        },
                        Ss: function() {
                            this.ds.Is()
                        },
                        Ts: function() {
                            window.confirm("Please confirm to end your room!") && this.ds.As()
                        },
                        Ms: function(t) {
                            this.Ds(-1)
                        },
                        js: function(t) {
                            this.Ds(1)
                        },
                        Rs: function(t) {
                            t.preventDefault(), t = a.o(t.currentTarget), this.Fs(t)
                        },
                        Us: function(t) {
                            this.ws.html(t), this.gs = this.ws.find("a"), this.gs.click(a.o.proxy(this.Rs, this)), this.Ls()
                        },
                        Ls: function() {
                            var t = this.gs.filter("[data-num=".concat(this.bs, "]"));
                            this.Ns(t)
                        },
                        Ns: function(t) {
                            t.hasClass("active") || (this.gs.removeClass("active"), t.addClass("active"))
                        },
                        Vs: function() {
                            return this.gs.filter(".active")
                        },
                        Ds: function(t) {
                            var e = this.Vs();
                            (e = this.gs.index(e) + t) < 0 ? o.Toast("You are playing the first episode.", o.Toast.Z) : e >= this.gs.length ? o.Toast("You are playing the last episode.", o.Toast.Z) : this.Fs(this.gs.eq(e))
                        },
                        Fs: function(t) {
                            var e = this;
                            this.Bs ? o.Toast("Please wait for episode loading.", o.Toast.Z) : (this.Bs = !0, o.Toast("Start loading episode ".concat(t.data("num"), "."), o.Toast.X), this.Ns(t), this.L.modal("hide"), this.ds.Fs(t, function() {
                                e.Bs = !1
                            }))
                        },
                        Ps: function(t) {
                            var e = t.closest(".episodes"),
                                i = {
                                    scrollTop: t = t.offset().top + e.scrollTop() - e.offset().top - 10,
                                    duration: 150
                                };
                            e.animate(i)
                        },
                        Os: function() {
                            var t = this;
                            a.o.ajax("ajax/watch2gether/room/episodes/".concat(this.ps, "/").concat(this._s)).done(function(e) {
                                t.Us(e.result)
                            })
                        }
                    }),
                    h = a.FW.define("RoomManager", {
                        u: function(t) {
                            var e = this;
                            this.wt = t, this.qs = t.data("id"), this.Ws = t.data("mode"), this.$s = t.data("owner-id"), this.Hs = t.data("started"), this.Gs = t.data("ended"), this.zs = t.data("start-at"), this.Ks = t.data("user"), this.Ys = a.o(".viewer-count"), this.Js = t.find(".player"), this.Xs = !1, this.Zs = t.data("now"), this.Qs, this.ta = new d(t, this), this.ia = t.find(".current-episode-name"), this.ea = t.find("#chat-input"), this.sa = t.find("#chat-send"), this.aa = t.find(".messages .scroll"), this.na = t.find(".load-more"), this.ra = 0, this.oa(), this.ha(), this.ca(), this.ua(), this.sa.click(a.o.proxy(this.fa, this)), this.ea.keypress(a.o.proxy(this.va, this)), this.na.click(a.o.proxy(this.ca, this)), this.Zs++, setInterval(function() {
                                return e.Zs++
                            }, 1e3)
                        },
                        Fs: function(t, e) {
                            var i = this;
                            !this.Gs && "manual" == this.Ws && this.la() && n.default.j("ajax/watch2gether/room/change", ["type", "POST", "data", ["id", this.qs, "episode", t.data("id")]]).done(function(e) {
                                200 !== e.status ? o.Toast.J(e) : i.N(10, {
                                    media: e.result,
                                    episode: t.data("num")
                                })
                            }).always(function() {
                                e && e()
                            })
                        },
                        la: function() {
                            return this.$s == this.Ks.id
                        },
                        da: function() {
                            return "manual" === this.Ws
                        },
                        ua: function() {
                            var t, e, i, a = this;
                            !this.Gs && (this.Hs ? this.pa() : this.zs && (t = 600 < this.zs - this.Zs, (i = function() {
                                a.Zs >= a.zs && (a.Is(!0), clearInterval(e), t ? window.location.reload() : a.pa())
                            })(), e = setInterval(i, 1e3)))
                        },
                        pa: function(t) {
                            var e = this;
                            this.Gs || n.default.j(atob(t || this.wt.data("media"))).done(function(t) {
                                200 === t.status ? (e._n = t.result, e.ma()) : o.Toast("Video is not available, please try again.", o.Toast.Z)
                            }).fail(function() {
                                o.Toast("Unable to get video info, please try again.", o.Toast.Z)
                            })
                        },
                        ma: function() {
                            var t, e, i, n = this;
                            this.Xs || !this._n || (this.Xs = !0, this.Js.empty(), this.ba = (0, a.o)("<div />").attr("id", "player").appendTo(this.Js), this.Qs = r(this.ba[0]).setup({
                                sources: this._n.sources,
                                width: "100%",
                                height: "100%",
                                primary: "html5",
                                hlshtml: !0,
                                preload: "auto",
                                autostart: !0,
                                key: "",
                                playbackRateControls: !1
                            }).on("ready", function() {
                                document.querySelectorAll(".jwplayer").forEach(function(t) {
                                    t.addEventListener("keydown", function(t) {
                                        return t.stopImmediatePropagation()
                                    }, !0)
                                })
                            }), this.da() ? this.la() ? this.Qs.on("seek", function(t) {
                                var e = {
                                    position: t.offset
                                };
                                n.N(6, e)
                            }).on("play", function(t) {
                                n.N(6, {
                                    position: n.Qs.getPosition()
                                }), n.N(8)
                            }).on("pause", function(t) {
                                n.N(7), n.N(6, {
                                    position: n.Qs.getPosition()
                                })
                            }) : this.Qs.once("play", function() {
                                setTimeout(function() {
                                    return n.ka()
                                }, 1e3), setTimeout(function() {
                                    return n.ka()
                                }, 3e3)
                            }).on("bufferFull", function(t) {
                                n.ka()
                            }).on("pause", function(t) {
                                n.ka()
                            }).on("play", function(t) {
                                n.ka()
                            }) : (this.zs || (this.zs = this.Zs), t = !0, this.Qs.on("play", function() {
                                t && (n.Qs.seek(Math.max(0, n.Zs - n.zs)), t = !1)
                            }).on("pause", function() {
                                t = !0
                            }).on("complete", function() {
                                n.wa()
                            })), this.da() && this.la()) || (e = 0, i = setInterval(function() {
                                n.Js.find(".jw-slider-time, .jw-icon-rewind, .jw-icon-pip").remove(), 3e3 <= (e += 150) && clearInterval(i)
                            }, 100))
                        },
                        ka: function() {
                            this.ga || (this.ga = 1), this.ga + 3 < this.Zs && (this.ga = this.Zs, this.N(9, {
                                user: this.Ks
                            }))
                        },
                        ya: function(t) {
                            this.la() && this.Qs && (t ? this.N(6, {
                                position: this.Qs.getPosition(),
                                toUser: t.id
                            }) : this.N(6, {
                                position: this.Qs.getPosition()
                            }), "paused" === this.Qs.getState() ? this.N(7) : this.N(8))
                        },
                        xa: function(t, e) {
                            if (this.Qs && !this.la()) switch (this.ga = this.Zs, t) {
                                case 8:
                                    "paused" === this.Qs.getState() && this.Qs.play();
                                    break;
                                case 7:
                                    "paused" !== this.Qs.getState() && this.Qs.pause();
                                    break;
                                case 6:
                                    e.data.toUser && e.data.toUser != this.Ks.id || this.Qs.seek(Math.max(0, e.data.position - .1))
                            }
                        },
                        oa: function() {
                            var t = new WebSocket("wss://anikoto.to/wsanime");
                            t.onopen = a.o.proxy(this.Sa, this), t.onmessage = a.o.proxy(this.Ta, this), t.onclose = a.o.proxy(this.Ca, this), t.onerror = a.o.proxy(this.Ma, this), this.ja = t
                        },
                        Sa: function(t) {
                            this.ra = 0, this.Oa(1, {
                                room_id: this.qs,
                                user: this.Ks
                            })
                        },
                        Ta: function(t) {
                            try {
                                var e = JSON.parse(t.data);
                                switch (e.cmd) {
                                    case 4:
                                        this.Ys.text(e.data.total), this.Ea("user_connected", e.data.user), this.Zs = e.data.time, this.ya(e.data.user);
                                        break;
                                    case 5:
                                        this.Ys.text(e.data.total), this.Ea("user_disconnected", e.data.user);
                                        break;
                                    case 9:
                                        this.ya(e.data.user);
                                        break;
                                    case 2:
                                        this.pa(), this.Ea("room_started");
                                        break;
                                    case 3:
                                        this.wa();
                                        break;
                                    case 10:
                                        this.Xs = !1, this.pa(e.data.media), this.ia.text(e.data.episode);
                                        break;
                                    case 8:
                                    case 7:
                                    case 6:
                                        this.xa(e.cmd, e);
                                        break;
                                    case 1:
                                        this.Ea("chat", e.data)
                                }
                            } catch (t) {}
                        },
                        Ca: function(t) {
                            ++this.ra < 3 ? this.oa() : o.Toast("Server connection closed.", o.Toast.Z)
                        },
                        Ma: function(t) {},
                        N: function(t, e) {
                            return this.Oa(2, this.Pa(t, e))
                        },
                        Oa: function(t, e) {
                            return 1 === this.ja.readyState && (this.ja.send(JSON.stringify(this.Pa(t, e))), !0)
                        },
                        Pa: function(t, e) {
                            return {
                                cmd: t,
                                data: e
                            }
                        },
                        Ea: function(t, e, i) {
                            switch (t) {
                                case "chat":
                                    var n = a.o("<div />").addClass("message"),
                                        s = a.o("<div />").addClass("avatar").append(a.o("<img />").attr("src", e.user.avatar_url)),
                                        o = a.o("<div />").addClass("msg-body").append(a.o("<div />").addClass("text").text(e.content)).append(a.o("<div />").addClass("user").text(e.user.name));
                                    e.user.id == this.Ks.id ? n.addClass("self") : this.$s === e.user.id && n.addClass("owner"), n.append(s).append(o), i ? this.na.after(n) : (this.aa.append(n), this.aa.animate({
                                        scrollTop: this.aa[0].scrollHeight
                                    }));
                                    break;
                                case "user_connected":
                                    a.o("<div />").addClass("event").text("".concat(e.name || "a viewer", " has joined")).appendTo(this.aa);
                                    break;
                                case "user_disconnected":
                                    a.o("<div />").addClass("event").text("".concat(e.name || "a viewer", " has left")).appendTo(this.aa);
                                    break;
                                case "room_started":
                                    a.o("<div />").addClass("event started").text("This show has been started, hope you enjoy it").appendTo(this.aa)
                            }
                        },
                        Is: function(t) {
                            var e = this;
                            n.default.j("ajax/watch2gether/room/start", ["type", "POST", "data", ["id", this.qs, "vrf", n.default.O(this.qs)]]).done(function(i) {
                                t || o.Toast.J(i), 200 === i.status && i.result && (e.Hs = !0, e.N(2), setTimeout(function() {
                                    return e.ya()
                                }, 3e3), setTimeout(function() {
                                    return e.ya()
                                }, 5e3))
                            })
                        },
                        As: function() {
                            var t = this;
                            n.default.j("ajax/watch2gether/room/end", ["type", "POST", "data", ["id", this.qs, "vrf", n.default.O(this.qs)]]).done(function(e) {
                                o.Toast.J(e), 200 === e.status && e.result && (t.Js.html(e.result), t.la()) && t.N(3)
                            })
                        },
                        wa: function() {
                            var t = this;
                            "manual" != this.Ws && n.default.j("ajax/watch2gether/room/end", ["type", "POST", "data", ["id", this.qs, "vrf", n.default.O(this.qs)]]).done(function(e) {
                                if (200 === e.status) {
                                    try {
                                        t.Qs.pause()
                                    } catch (t) {}
                                    t.Js.html(e.result)
                                }
                            })
                        },
                        fa: function(t) {
                            this.Fa()
                        },
                        va: function(t) {
                            13 === t.keyCode && this.Fa()
                        },
                        ca: function() {
                            var t, e, i = this;
                            this.Ia || (this.Ia = !0, t = (this.na.data("page") || 0) + 1, e = !1, this.na.html(this.na.data("loader")), n.default.j("ajax/watch2gether/chat/list/".concat(this.qs), ["data", ["page", t]]).done(function(a) {
                                if (200 === a.status) {
                                    for (var n = 0; n < a.result.messages.length; n++) i.Ea("chat", a.result.messages[n], !0);
                                    e = a.result.hasMore, i.na.data("page", t)
                                }
                            }).always(function() {
                                e ? i.na.html(i.na.data("more")) : i.na.hide(), i.Ia = !1
                            }))
                        },
                        Fa: function() {
                            var t, e = this;
                            s.Visitor.me() || "" === (t = a.o.trim(this.ea.val())) || this.Aa || (1e3 <= t.length ? o.Toast("Your message is too long", o.Toast.Z) : (this.Aa = !0, this.N(1, {
                                content: t
                            }) && this.ea.val(""), n.default.j("ajax/watch2gether/chat/save", ["type", "POST", "data", ["room_id", this.qs, "content", t, "vrf", n.default.O("".concat(this.qs).concat(t))]]).done(function(t) {
                                t.result || o.Toast.J(t)
                            }).always(function() {
                                e.Aa = !1
                            })))
                        },
                        ha: function() {
                            var t, e, i, n, s, o, r;
                            window.innerWidth < 1200 || (t = this.wt.find(".wg2-watch-block"), e = this.wt.find(".room-chat"), s = a.o(window), r = function() {
                                window.scrollY;
                                var t = document.body.clientHeight + window.scrollY - n - 0 - 10;
                                t = Math.min(t, i - 0), e.css("max-height", t)
                            }, (o = function() {
                                e.attr("style", ""), i = t.height(), n = e.offset().top
                            })(), r(), s.scroll(r), s.resize(function() {
                                o(), r()
                            }))
                        }
                    });
                i.default = function() {
                    c.bind(".w2g-create-container"), h.bind(".w2g-watch")
                }
            }, {
                11: 11,
                13: 13,
                3: 3,
                6: 6
            }],
            15: [function(t, e, i) {
                function a(t) {
                    return (a = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
                        return typeof t
                    } : function(t) {
                        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
                    })(t)
                }

                function n() {}

                function s() {
                    var t = [arguments];
                    return t[4] = 2, n.F2(), t[8] = encodeURIComponent("" + t[0][0]), t[8] = function() {
                        var t = [arguments];
                        for (t[1] = "lengt", t[1] += 9, t[3] = [], t[7] = 0, t[9] = 0, t[4] = 10, t[9] = 0; t[9] < 256; t[9]++) t[3][t[9]] = t[9];
                        for (t[9] = 0; t[9] < 256; t[9]++) t[8] = "leng", t[8] += 11, n.u1(0), t[48] = n.u$(192, 64), t[7] = (t[3][t[9]] + t[9] % t[0][0][t[8]]) % t[48], t[6] = t[3][t[9]], t[3][t[9]] = t[3][t[7]], t[3][t[7]] = t[6];
                        for (t[9] = 0, t[7] = 0, n.F2(), t[99] = 0; t[99] < t[0][1][t[1]]; t[99]++) t[5] = 0, t[5] += "C", t[5] += "od", t[5] += 5, t[2] = "f", t[2] += 8, t[2] += 13, n.u1(1), t[9] = n.u$(1, 256, t[9]), n.q_(2), t[92] = n.u$(3317, 255, 11, 3328), t[7] = (t[7] + t[3][t[9]]) % t[92], t[6] = t[3][t[9]], t[3][t[9]] = t[3][t[7]], t[3][t[7]] = t[6], t[4] += String[t[2]](t[0][1][t[5]](t[99]) ^ t[3][(t[3][t[9]] + t[3][t[7]]) % 256]);
                        return t[4]
                    }(t[4], t[8]), t[8] = (t[8], n.T7(), ""), t[8]
                }
                Object.defineProperty(i, "i", {
                    value: !0
                }), i.default = void 0;
                var o, r = t(3),
                    c = t(2),
                    d = t(6),
                    h = t(13),
                    l = t(8),
                    u = t(11),
                    f = window.Swiper,
                    p = "SEEK";
                r.FW.define("WatchSeasons", {
                    u: function(t) {
                        var e = t.find(".season.active").index();
                        new f(t[0], {
                            grabCursor: !0,
                            pagination: {
                                el: ".swiper-pagination",
                                clickable: !0,
                                renderBullet: function(t, e) {
                                    return (e.qOjaB(e.qOjaB("<", "span") + " class", "=") + '"').concat(e, e.oSWFB('"></', "span") + ">")
                                }
                            },
                            slidesPerView: "auto",
                            slidesPerGroup: 3
                        }).slideTo(e)
                    }
                });
                var m = r.FW.define("ReportEpisode", l.AjaxForm.prototype, {
                        Da: function(t) {
                            this.Ra = t
                        },
                        q: function() {
                            this.Ua = this.L.find("#report-episode"), this.La = this.I.find("#report-episode-id"), this.Na = this.I.find("#report-server-id"), this.L.on("show.bs.modal", r.o.proxy(this.os, this))
                        },
                        os: function() {
                            var t = this.Ra.Va(),
                                e = this.Ra.Ba();
                            this.Ua.text(t.data("num")), this.La.val(e.data("ep-id")), this.Na.val(e.data("sv-id")), this.ft()
                        },
                        lt: function() {
                            var t;
                            return this.qa ? (this.ft(), this.it(["Your report already submitted."], l.AjaxForm.Z), !1) : void 0 === (t = (0, c.formSerialize)(this.I))[1]["issue[0]"] || "" !== t[1]["issue[0]"] || "" !== r.o.trim(t[1].message) || ((0, u.Toast)("Please fill the form.", u.Toast.Z), !1)
                        },
                        ht: function() {
                            var t = this;
                            this.qa = !0, setTimeout(function() {
                                t.L.modal("hide"), t.rt()
                            }, 2e3)
                        }
                    }),
                    v = r.FW.define("OnOffControl", {
                        Wa: [],
                        u: function(t) {
                            this.$a(t), this.Ha()
                        },
                        Ga: function(t) {
                            this.Wa.push(t)
                        },
                        $a: function(t) {
                            this.Oe = t, this.Ot = t.data("default"), this.Mt = t.data("persist"), this.Mt && (this.za = this.Oe.data("name"), void 0 !== (t = h.Visitor.Et(this.za))) && (this.Ot = t), this.kt(), this.Oe.click(r.o.proxy(this.Ne, this))
                        },
                        Ne: function(t) {
                            this.Ot = !this.Ot, this.Mt && h.Visitor.Rt(this.za, this.Ot ? 1 : 0);
                            for (var e = 0; e < this.Wa.length; e++) this.Wa[e]();
                            this.kt(), this.Ka()
                        },
                        kt: function() {
                            var t = this.Ot ? "on" : "off";
                            this.Oe.data(t) && this.Oe.html(this.Oe.data(t))
                        },
                        Ka: function() {},
                        Ha: function() {}
                    }),
                    g = r.FW.define("LightControl", v.prototype, {
                        Ha: function() {
                            this.Ya = r.o("<div />").css("width", "100%").css("height", "100%").css("position", "fixed").css("left", 0).css("top", 0).css("z-index", 43046721).css("background", "#000").css("opacity", "0.95").css("display", "none").appendTo(document.body).click(r.o.proxy(this.Ne, this)), this.ba = r.o("#player-wrapper")
                        },
                        Ka: function() {
                            var t = this;
                            this.Ot ? this.Ya.fadeOut(function() {
                                t.ba.removeAttr("style")
                            }) : (this.Ya.fadeIn(), this.ba.css("z-index", 387420489))
                        }
                    }),
                    y = r.FW.define("ExpandControl", v.prototype, {
                        u: function(t, e) {
                            this.$a(t), this.wt = e
                        },
                        Ka: function() {
                            this.wt.toggleClass("expand")
                        }
                    }),
                    w = r.FW.define("ForwardEpisodeControl", v.prototype, {
                        u: function(t, e) {
                            this.$a(t), this.Ra = e, this.Oe.show()
                        },
                        Ka: function() {
                            this.Oe.hasClass("next") ? this.Ra.Ds(1) : this.Ra.Ds(-1)
                        }
                    }),
                    b = r.FW.define("Rating", {
                        Ja: {
                            10: "Masterpiece",
                            9: "Great",
                            8: "Very Good",
                            7: "Good",
                            6: "Fine",
                            5: "Average",
                            4: "Bad",
                            3: "Very Bad",
                            2: "Horrible",
                            1: "Appalling"
                        },
                        u: function(t) {
                            this.wt = t, this.Xa = t.find(".stars span"), this.Za = t.find(".message"), this.Ot = t.data("score"), this.Ee = t.data("id"), this.Qa = r.Storage.get("rated.".concat(this.Ee)), this.Qa ? this.tn() : (this.Za.data("html", this.Za.html()), this.bi(), this.Xa.mousemove(r.o.proxy(this.en, this)).mouseout(r.o.proxy(this.sn, this)).click(r.o.proxy(this.an, this)))
                        },
                        Pi: function(t) {
                            for (var e = 1; e <= 5; e++) {
                                var i = "";
                                2 * e - 1 < t ? i = "full" : 2 * (e - 1) < t && t < 2 * e && (i = "half"), r.o(this.Xa[e - 1]).attr("class", i)
                            }
                        },
                        tn: function() {
                            this.Za.html(this.wt.data("rated").replace("%s", this.Ja[this.Qa] || this.Qa)), this.Xa.off("mousemove").off("click").off("mouseout"), this.Pi(this.Qa)
                        },
                        an: function(t) {
                            r.Storage.set("rated.".concat(this.Ee), this.Qa), this.tn();
                            var e = d.default.M();
                            d.default.j("ajax/anime/rate", ["type", "POST", "data", ["id", this.Ee, "score", this.Qa, "req_id", e, "vrf", s("".concat(this.Ee, "@").concat(this.Qa, "@").concat(e))]]).done(function(t) {
                                u.Toast.J(t)
                            })
                        },
                        sn: function(t) {
                            this.bi()
                        },
                        en: function(t) {
                            var e = r.o(t.currentTarget);
                            this.nn || (this.nn = e.outerWidth()), this.rn(e.index(), t.offsetX > this.nn / 2, !0)
                        },
                        bi: function() {
                            this.Pi(this.Ot), this.Za.html(this.Za.data("html"))
                        },
                        rn: function(t, e) {
                            t = 2 * (t + 1) - (e ? 0 : 1), this.Qa = t, this.Za.text(this.Ja[t]), this.Pi(t)
                        }
                    }),
                    x = r.FW.define("SkipTime", {
                        u: function(t) {
                            var e = this;
                            this.Oe = t, this.A = t.find("input"), this.on = this.A.filter('[name="intro_begin"]'), this.hn = this.A.filter('[name="intro_end"]'), this.cn = this.A.filter('[name="outro_begin"]'), this.un = this.A.filter('[name="outro_end"]'), this.fn = null, this.vn = null, this.gt = t.find('[data-toggle="dropdown"]'), this.ei = t.find("button"), this.ln = 0, this.dn = window.innerWidth <= 1024, this.dn ? this.Oe.hide() : (u.Broadcast.Ft("video:unloaded", function() {
                                return e.pn()
                            }), u.Broadcast.Ft("video:metaloaded", r.o.proxy(this._a, this)), u.Broadcast.Ft("video:seek", r.o.proxy(this.mn, this)), this.gt.mouseout(function() {
                                return e.bn()
                            }), this.Oe.click(r.o.proxy(this.Ne, this)), this.A.focus(r.o.proxy(this.li, this)).change(r.o.proxy(this.St, this)), this.ei.click(r.o.proxy(this.B, this)))
                        },
                        Ne: function(t) {
                            h.Visitor.me() && t.stopPropagation()
                        },
                        kn: function() {
                            return this.hn.data("value") || this.un.data("value") ? this.on.data("value") && !this.hn.data("value") || this.on.data("value") && this.on.data("value") == this.hn.data("value") ? ((0, u.Toast)("Intro value are missing or incorrect.", u.Toast.Z), !1) : !(this.cn.data("value") && !this.un.data("value") || !this.cn.data("value") && this.un.data("value") || this.cn.data("value") && this.cn.data("value") == this.un.data("value")) || ((0, u.Toast)("Outro value are missing or incorrect.", u.Toast.Z), !1) : ((0, u.Toast)("Please fill at least intro or outro.", u.Toast.Z), !1)
                        },
                        B: function() {
                            var t, e;
                            this.kn() && (t = [], e = "", this.A.each(function(i, a) {
                                var n = (a = r.o(a)).data("value") || "";
                                t.push(a.attr("name")), t.push(n), e += "".concat(n)
                            }), t.push("id"), t.push(this.vn), t.push("vrf"), t.push(s(e)), d.default.j("ajax/episode/skiptime/save", ["type", "POST", "data", t]).done(function(t) {
                                u.Toast.J(t)
                            }))
                        },
                        pn: function() {
                            this.Oe.hide(), this.A.val("").data("value", "")
                        },
                        bn: function() {
                            this.Oe.tooltip("hide")
                        },
                        St: function(t) {
                            var e = r.o(t.currentTarget),
                                i = r.o.trim(e.val());
                            /^\d{1,2}:\d{1,2}:\d{1,2}$/.test(i) ? (t = 3600 * Math.min(3, (t = i.split(":"))[0]) + 60 * Math.min(60, t[1]) + Math.min(60, t[2]), t = Math.min(this.ln, t), e.val(d.default.C(t)).data("value", t)) : e.val("").data("value", "");
                            for (var a = 0; a < this.A.length - 1; a++) {
                                var n = r.o(this.A[a]),
                                    s = r.o(this.A[a + 1]);
                                n.data("value") && s.data("value") && n.data("value") > s.data("value") && (n[0] == e[0] ? (i = Math.max(n.data("value"), s.data("value")), s) : (i = Math.min(n.data("value"), s.data("value")), n)).data("value", i).val(d.default.C(i))
                            }
                        },
                        li: function(t) {
                            t = r.o(t.currentTarget), this.fn = t, this.bn()
                        },
                        mn: function(t) {
                            this.Oe.hasClass("show") && (this.fn ? this.fn.val(d.default.C(t.offset)).data("value", Math.floor(t.offset)).trigger("change") : u.Toast(66..MAbcC("Please select", " ") + "an input field first.", u.Toast.Z))
                        },
                        _a: function(t, e) {
                            this.dn || "media" !== e.metadataType || (this.ln = Math.floor(e.duration), this.vn = t, this.Oe.show())
                        }
                    }),
                    k = r.FW.define("WatchView", {
                        u: function(t, e) {
                            this.ds = t, this.Ee = e.data("id"), this.wn = e.data("url"), this.gn = e.data("ep-name"), this.yn = e.data("ep-type"), this.wt = e, this.xn = e.find("#w-episodes"), this.Sn = e.find("#w-servers"), this.ba = e.find("#player"), this.Tn = this.ba.find(".play").hide(), this.Cn = !1, this.gs = null, this.Mn = null, this.jn, this.On = r.o(".current-episode-name"), this.En = r.o(".current-episode-type"), this.Pn = e.find(".ctrl.w2g"), this.Fn = r.o("#comments"), this.In = this.Fn.find(".tabs .tab"), this.An = this.Fn.find("button.load-comments"), void 0 !== (t = h.Visitor.Et("auto_load_comment")) && this.Fn.data("load", t), this.In.click(r.o.proxy(this.Dn, this)), this.An.click(r.o.proxy(this.Rn, this))
                        },
                        Dn: function(t) {
                            t = r.o(t.currentTarget), this.Un(t)
                        },
                        Rn: function(t) {
                            var e = this.In.filter(".active");
                            this.Fn.data("load", !0), this.Un(e)
                        },
                        Un: function(t) {
                            switch (t.data("type")) {
                                case "anime":
                                    this.Ln();
                                    break;
                                case "episode":
                                    this.Nn()
                            }
                        },
                        Ln: function() {
                            var t = this.Fn.data("id"),
                                e = this.Fn.data("link");
                            this.Vn(t, e)
                        },
                        Nn: function() {
                            this.In.removeClass("active").filter('[data-type="episode"]').addClass("active");
                            var t = this.Va(),
                                e = this.Ba(),
                                i = e.closest(".type").data("type");
                            e = e.data("cmid"), t = t.data("slug");
                            var a = this.Fn.data("link");
                            "softsub" === i && (i = "sub", e = this.Bn.filter('[data-type="sub"] [data-cmid]').first().data("cmid")), this.Vn("".concat(e, "_").concat(t), "".concat(a, "/ep-").concat(t, "?type=").concat(i))
                        },
                        Vn: function(t, e) {
                            try {
                                window.disqus_config = function() {
                                    e.includes("gogoanime") && e.includes("ep") && (e = (e = e.replace("/category/", "/")).replace("/ep-", "-episode-")), (e = e.replace("?type=sub", "")).includes("gogoanime") && e.includes("episode") && e.includes("dub") && (e = (e = e.replace("?type=dub", "")).replace("-episode-", "-dub-episode-")), this.page.url = e
                                }
                            } catch (t) {}
                            this.Fn.data("load") && this.qn != t && (this.qn = t, this.Wn())
                        },
                        Wn: function() {
                            this.An.remove(), this.$n || (this.$n = !0, (e = (t = document).createElement("script")).src = this.Fn.data("src"), e.setAttribute("data-timestamp", +new Date), (t.head || t.body).appendChild(e));
                            try {
                                var t, e;
                                window.DISQUS.reset({
                                    reload: !0
                                })
                            } catch (t) {}
                            this.Hn()
                        },
                        Hn: function() {
                            var t = 0,
                                e = setInterval(function() {
                                    30 < t++ ? clearInterval(e) : r.o("iframe").each(function(t, i) {
                                        var a = i.getAttribute("name");
                                        a && -1 < a.indexOf("dsq") && !i.getAttribute("src") && (i.parentNode.removeChild(i), clearInterval(e))
                                    })
                                }, 500)
                        },
                        Gn: function() {
                            var t = this.ba.find("iframe");
                            this.ba.removeAttr("style"), t.length ? (t.attr("src", "").css("visibility", "hidden"), this.ba.find(".loading-overlay").remove(), this.ba.append('<div class="loading loading-overlay" />')) : this.ba.html('<div class="loading" />')
                        },
                        zn: function(t) {
                            this.ba.removeAttr("style").empty().append(r.o('<div class="message" />').text(t))
                        },
                        Kn: function() {
                            var t;
                            this.Yn = this.wt.find(".filter.type .dropdown-toggle"), this.Jn = this.wt.find(".filter.type .dropdown-item"), this.Mn = this.gs, 1 < this.Jn.length && (t = this.Xn(), this.Zn(t)), this.Jn.click(r.o.proxy(this.Qn, this))
                        },
                        Xn: function() {
                            return arguments.length ? h.Visitor.Rt("prefered_source_type", arguments[0]) : h.Visitor.Et("prefered_source_type") || ""
                        },
                        Qn: function(t) {
                            t = r.o(t.currentTarget).data("value"), this.Xn(t), this.Zn(t)
                        },
                        Zn: function(t) {
                            var e = (t = (t = this.Jn.filter('[data-value="'.concat(t, '"]'))).length ? t : this.Jn.first()).data("value"),
                                i = t.text();
                            t.hasClass("active") || (this.Jn.removeClass("active"), t.addClass("active")), this.Yn.data("value", e).text(i), this.tr(e)
                        },
                        tr: function(t) {
                            var e;
                            t ? (e = [], this.gs.each(function(i, a) {
                                var n = r.o(a);
                                1 == n.data(t) ? (n.show().attr("enabled", 1), e.push(a)) : n.hide().attr("enabled", 0)
                            }), this.Mn = r.o(e), this.er()) : (this.Mn = this.gs.show().attr("enabled", 1), this.ir.show())
                        },
                        sr: function() {
                            this.ar = this.wt.find(".filter.range .dropdown-toggle"), this.ir = this.wt.find(".filter.range .dropdown-item");
                            var t = this.ir.first();
                            this.ar.data("value", t.data("value")).text(t.text()), this.ir.click(r.o.proxy(this.nr, this))
                        },
                        rr: function(t) {
                            var e = (t = this.ir.filter('[data-value="'.concat(t, '"]'))).data("value"),
                                i = t.text();
                            t.hasClass("active") || (this.ir.removeClass("active"), t.addClass("active")), this.ar.data("value", e).text(i), this.jn.forEach(function(t) {
                                t.hr.data("range") == e ? t.hr.show() : t.hr.hide()
                            })
                        },
                        nr: function(t) {
                            t = r.o(t.currentTarget), this.rr(t.data("value"))
                        },
                        er: function() {
                            for (var t = this.ar.data("value"), e = !1, i = !1, a = this.jn.length - 1; 0 <= a; a--) {
                                var n = this.jn[a],
                                    s = n.hr.data("range");
                                i || s != t || (i = !0), n.cr.filter('[enabled="1"]').length ? (n.ur.show(), !e && i && (e = !0, s != t) && this.rr(s)) : n.ur.hide()
                            }
                        },
                        vr: function() {
                            this.lr = this.wt.find(".filter.name input"), this.lr.keyup(r.o.proxy(this.dr, this))
                        },
                        dr: function(t) {
                            var e = this,
                                i = this.lr.val().replace(/[^0-9]/g, "");
                            this.lr.val(i), this.pr && clearTimeout(this.pr), this.pr = setTimeout(function() {
                                return e.th(i, 13 == t.keyCode)
                            }, 250)
                        },
                        th: function(t, e) {
                            if (this.mr && this.mr.removeClass("highlight"), "" != t)
                                for (var i = 0; i < this.Mn.length; i++) {
                                    var a = r.o(this.Mn[i]);
                                    if (a.data("num") == t) {
                                        a.addClass("highlight"), this.mr = a, this.br(a), this.Ps(a), e && this.kr(a);
                                        break
                                    }
                                }
                        },
                        wr: function(t) {
                            window.history.replaceState("", "", t)
                        },
                        gr: function(t) {
                            t = "".concat(t.data("ids")).split(","), this.Pn.show().attr("href", "watch2gether/create/".concat(t[0]))
                        },
                        yr: function(t) {
                            t.hasClass("active") || (t.addClass("active"), this.gs.each(function(e, i) {
                                i != t[0] && r.o(i).removeClass("active")
                            })), this.gr(t), this.wr(t.attr("href")), this.br(t), this.On.text(t.data("num"))
                        },
                        br: function(t) {
                            var e = t.closest(".ep-range").data("range");
                            "0" == t.attr("enabled") && this.Zn(null), this.rr(e)
                        },
                        Ps: function(t) {
                            if (t && this.Sr) {
                                let e = t.offset(),
                                    i = this.Sr.offset();
                                e && i ? t = e.top + this.Sr.scrollTop() - i.top - 10 : console.error("Offset method failed: target or this.Sr might not be a valid jQuery object or DOM element.")
                            } else console.error("target or this.Sr is not defined or not a valid jQuery object or DOM element.");
                            var e = {
                                scrollTop: t,
                                duration: 150
                            };
                            this.Sr.animate(e)
                        },
                        Tr: function() {
                            var t = this;
                            this.jn = [], this.xn.find(".ep-range").each(function(e, i) {
                                var a = (i = r.o(i)).data("range");
                                t.jn.push({
                                    index: t.jn.length,
                                    ur: t.ir.filter('[data-value="'.concat(a, '"]')),
                                    hr: i,
                                    cr: i.find("a")
                                })
                            })
                        },
                        Va: function() {
                            return this.gs ? this.gs.filter(".active") : null
                        },
                        Ba: function() {
                            return this.Bn.filter(".active")
                        },
                        Cr: function() {
                            var t = this.Ba();
                            t.length && this.ds.Mr(t)
                        },
                        jr: function(t) {
                            var e = this.Ba();
                            e.length && (this.Cn = !0, this.ds.Mr(e))
                        },
                        Or: function(t) {
                            t.preventDefault(), t = r.o(t.currentTarget), this.kr(t)
                        },
                        kr: function(t) {
                            var e = this;
                            this.Gn(), this.yr(t), window.innerWidth <= 1024 && this.ba.scrollFocus(), this.Cn = !0, this.ds.Er(t, function() {
                                e.Cr()
                            })
                        },
                        Pr: function() {
                            var t = this.yn;
                            t ? this.yn = null : t = this.Xn() || r.Cookie.get("prefered_server_type"), this.Fr(t)
                        },
                        Ir: function() {
                            var t = this.Ba().next();
                            t.length && (this.Ar(t), this.ds.Mr(t))
                        },
                        Ar: function(t) {
                            var e;
                            t.hasClass("active") || (t.addClass("active"), this.Bn.each(function(e, i) {
                                i != t[0] && r.o(i).removeClass("active")
                            }), e = t.closest(".type").data("type"), this.En.text(e.toUpperCase()))
                        },
                        Fr: function(t) {
                            var e, i = r.Cookie.get("prefered_server_id");
                            !((e = !t || (e = i ? this.Dr.filter('[data-type="'.concat(t, '"]')).find('li[data-sv-id="'.concat(i, '"]')).first() : e) && e.length ? e : this.Dr.filter('[data-type="'.concat(t, '"]')).find("li").first()) && e.length) && i && (e = this.Dr.find('li[data-sv-id="'.concat(i, '"]')).first()), e && e.length || (e = this.Bn.first()), this.Ar(e)
                        },
                        Rr: function(t) {
                            t.preventDefault();
                            var e = (t = r.o(t.currentTarget)).data("sv-id"),
                                i = t.closest(".type").data("type");
                            r.Cookie.set("prefered_server_id", e, {
                                expires: 1
                            }), r.Cookie.set("prefered_server_type", i, {
                                expires: 1
                            }), this.Ar(t), this.Cn = !0, this.ds.Mr(t)
                        },
                        Ur: function() {
                            this.Dr = this.Sn.find(".servers .type"), this.Bn = this.Dr.find("li"), this.Bn.on("click", r.o.proxy(this.Rr, this))
                        },
                        Lr: function(t) {
                            (this.Cn || this.ds.Nr()) && (t += "".concat(0 > t.indexOf("?") ? "?" : "&", "autostart=true")), this.ba.find(".loading-overlay").remove(), this.ba.children().not("iframe").remove();
                            var e = this.ba.find("iframe");
                            e.length ? (e.off("load.reveal").one("load.reveal", function() {
                                r.o(this).css("visibility", "visible")
                            }), e.attr("src", t)) : (e = r.o("<iframe />").attr("src", t).attr("allow", "autoplay; fullscreen *").attr("allowfullscreen", "yes").attr("frameborder", "no").attr("scrolling", "no").css("width", "100%").css("height", "100%").css("overflow", "hidden"), this.ba.html(e))
                        },
                        Vr: function(t, e) {
                            (e = e || {}).cmd = t, (t = this.ba.find("iframe")).length && t[0].contentWindow.postMessage(JSON.stringify(e), "*")
                        },
                        Ds: function(t) {
                            var e = this,
                                i = this.Va();
                            !((i = this.Mn.index(i) + t) < 0) && (t = this.Mn.eq(i)) && t.length && (this.yr(t), this.Cn = !0, this.ds.Er(t, function() {
                                e.Cr()
                            }))
                        },
                        Br: function(t) {
                            this.Lr(t), this.Nn()
                        },
                        qr: function(t) {
                            this.Sn.html(t).activate(), this.Ur(), this.Pr(), this.Nn()
                        },
                        Wr: function(t) {
                            var e = this;
                            this.xn.html(t).activate(), this.Sr = this.xn.find(".episodes"), this.gs = this.xn.find("a"), this.gs.each(function(t, i) {
                                (i = r.o(i)).attr("href", "".concat(e.wn, "/ep-").concat(i.data("slug"))), i.attr("enabled", 1)
                            }), this.sr(), this.Tr(), this.Kn(), this.vr(), this.Tn.fadeIn(), this.Tn.click(r.o.proxy(this.jr, this)), this.gs.click(r.o.proxy(this.Or, this))
                        },
                        $r: function(t, e) {
                            return t = this.gs.filter('[data-slug="'.concat(t, '"]:first')), e || t.length ? t : this.gs.first()
                        },
                        Hr: function(t, e) {
                            return t = this.gs.filter('[data-num="'.concat(t, '"]:first')), e || t.length ? t : this.gs.first()
                        },
                        Gr: function() {
                            try {
                                var t = this.ds.zr();
                                if (t && "object" === a(t) && Object.keys(t).length) {
                                    t.id;
                                    var e, i = t.num,
                                        n = t.slug;
                                    if (t.type, !this.gn || this.gn == n) return (e = this.gs.filter('[data-slug="'.concat(n, '"]')).first()).length ? e : this.gs.filter('[data-num="'.concat(i, '"]')).first()
                                }
                            } catch (t) {}
                        },
                        Kr: function() {
                            var t = this,
                                e = this.$r(this.gn);
                            this.yr(e), this.Ps(e), this.ds.Er(e, function() {
                                t.ds.Yr()
                            })
                        },
                        Jr: function() {
                            var t = this,
                                e = this.ds.zr();
                            if (e && "object" === a(e) && Object.keys(e).length && this.gs) try {
                                e.id;
                                var i = e.num,
                                    n = e.slug,
                                    s = e.type;
                                if (!this.gn || this.gn == n) {
                                    var o = this.Va();
                                    if (o && o.length && o.data("num") != i) {
                                        var r = this.$r(n, !0);
                                        if ((r = r.length ? r : this.Hr(i, !0)).length) return this.yr(r), this.ds.Er(r, function() {
                                            t.Fr(s), t.ds.Yr()
                                        }), !0
                                    }
                                }
                            } catch (t) {}
                        }
                    }),
                    T = r.FW.define("WatchManager", {
                        u: function(t) {
                            var e = this;
                            this.wt = t, this.Ee = t.data("id"), this.wn = t.data("url"), this.gn = t.data("ep-name"), this.Xr = null, this.Zr = !1, this.Ra = new k(this, t), this.Qr = new v(t.find(".ctrl.auto-play")), this.io = new v(t.find(".ctrl.auto-next")), this.eo = new v(t.find(".ctrl.auto-skip")), this.so = new x(t.find(".ctrl.skiptime")), new y(t.find(".ctrl.expand"), t), new m(r.o("#w-report form")).Da(this.Ra), this.eo.Ga(function() {
                                return e.ao()
                            }), this.no(), this.ro(), u.Broadcast.Ft("user:loaded", function() {
                                return e.oo()
                            }), this.Os(function() {
                                new w(t.find(".ctrl.prev"), e.Ra), new w(t.find(".ctrl.next"), e.Ra), e.ho = setTimeout(function() {
                                    e.co || e.Ra.Jr() || e.Ra.Kr()
                                }, 100)
                            })
                        },
                        oo: function() {
                            var t = this;
                            h.Visitor.Se(this.Ee, function(e) {
                                t.uo = !0, t.fo(e.id, e.num, e.slug, e.type, e.position), t.Ra.Jr() && (t.co = !0, t.ho) && clearTimeout(t.ho)
                            })
                        },
                        vo: function(t) {
                            var e, i, a;
                            this.eo.Ot && (e = this.Xr, t = Math.floor(t.position), e.intro[1] && t >= e.intro[0] && t < e.intro[1] ? (i = d.default.C(e.intro[0]), a = d.default.C(e.intro[1]), u.Toast("Auto Skip from ".concat(i, " to ").concat(a), u.Toast.X), this.lo(p, {
                                value: e.intro[1]
                            })) : e.outro[0] && t >= e.outro[0] && e.outro[1] && t < e.outro[1] && (i = d.default.C(e.outro[0]), a = d.default.C(e.outro[1]), u.Toast("Auto Skip from ".concat(i, " to ").concat(a), u.Toast.X), this.lo(p, {
                                value: e.outro[1]
                            })))
                        },
                        _a: function(t) {
                            var e = this.Ra.Va(),
                                i = this.Ra.Ba();
                            if (!this.do) try {
                                this.do = !0;
                                var a = this.zr();
                                a.num == e.data("num") && a.type == i.closest(".type").data("type") && this.lo(p, {
                                    value: a.position
                                })
                            } catch (t) {}
                        },
                        Yr: function() {
                            this.Qr.Ot && this.Ra.Cr()
                        },
                        po: function() {
                            var t = this;
                            this.io.Ot && (this.ih = !0, setTimeout(function() {
                                return t.ih = !1
                            }, 3e3), this.Ra.Ds(1))
                        },
                        ao: function() {
                            this.Xr && this.lo("SKP_DATA", {
                                value: [this.Xr.intro, this.Xr.outro],
                                auto: this.eo.Ot
                            })
                        },
                        mo: function(t) {
                            var e = this;
                            switch (t.event) {
                                case "PLAYER_READY":
                                    this.ao();
                                    break;
                                case "META_LOADED":
                                    u.Broadcast.ot("video:metaloaded", this.Ra.Ba().data("ep-id"), t.data), this.bo && clearTimeout(this.bo), "media" == t.data.metadataType && setTimeout(function() {
                                        return e._a(t.data)
                                    }, 100);
                                    break;
                                case "SEEK":
                                    u.Broadcast.ot("video:seek", t.data);
                                    break;
                                case "PLAY_TIMING":
                                    this.do && this.ko(t.data);
                                    break;
                                case "PLAY_COMPLETED":
                                    this.po();
                                    break;
                                case "EVENT_KEYBOARD":
                                    -1 == [32, 77].indexOf(t.data) && this.g(t.data)
                            }
                        },
                        no: function() {
                            var t = this;
                            r.o(window).on("message", function(e) {
                                var i = e.message || e.data || e.originalEvent.data;
                                if ("player.error" !== i) try {
                                    var a = JSON.parse(i);
                                    a && void 0 !== a.event && t.mo(a)
                                } catch (t) {}
                            })
                        },
                        ro: function() {
                            var t = this;
                            r.o(window).keydown(function(e) {
                                -1 === "INPUT,TEXTAREA".indexOf(e.target.tagName) && t.g(e.keyCode, e)
                            })
                        },
                        g: function(t, e) {
                            switch (t) {
                                case 66:
                                    this.Ra.Ds(-1);
                                    break;
                                case 78:
                                    this.Ra.Ds(1);
                                    break;
                                case 74:
                                    this.lo(p, {
                                        value: -Math.floor(Number.parseInt(h.Visitor.Et("skip_seconds")) || 5),
                                        skip: !0
                                    });
                                    break;
                                case 76:
                                    this.lo(p, {
                                        value: Math.floor(Number.parseInt(h.Visitor.Et("skip_seconds")) || 5),
                                        skip: !0
                                    });
                                    break;
                                case 32:
                                    this.lo("PLAY_TOGGLE"), e && e.preventDefault();
                                    break;
                                case 77:
                                    this.lo("MUTE")
                            }
                        },
                        ko: function(t) {
                            var e = this.Ra.Ba(),
                                i = this.Ra.Va(),
                                a = e.data("ep-id");
                            e = e.closest(".type").data("type");
                            var n = i.data("num");
                            i = i.data("slug");
                            var s = t.position ? Math.floor(t.position) : 0;
                            t = Math.floor(t.duration), h.Visitor.xe(this.Ee, a, s, t), this.fo(a, n, i, e, s)
                        },
                        zr: function() {
                            return r.Storage.get("playing.".concat(this.Ee))
                        },
                        fo: function(t, e, i, a, n) {
                            r.Storage.set("playing.".concat(this.Ee), {
                                id: t,
                                num: e,
                                slug: i,
                                type: a,
                                position: n
                            })
                        },
                        lo: function(t, e) {
                            this.Ra.Vr(t, e)
                        },
                        Nr: function() {
                            return this.Qr.Ot
                        },
                        Mr: function(t) {
                            var e = this;
                            h.Visitor.Ce(this.Ee), t = t.data("link-id"), this.bo && clearTimeout(this.bo), this.bo = setTimeout(function() {
                                e.ko({
                                    position: 0,
                                    duration: 9
                                })
                            }, 1e4), u.Broadcast.ot("video:unloaded"), this.ih || this.Ra.Gn();
                            var i = 1 === Number(h.Visitor.Et("auto_skip_intro")) ? 1 : 0,
                                a = 1 === Number(h.Visitor.Et("auto_play")) ? 1 : 0;
                            d.default.j("ajax/sources?id=" + t + "&asi=" + i + "&autoPlay=" + a).done(function(t) {
                                if (200 !== t.status) e.Ra.zn(t.message);
                                else {
                                    e.Ra.Br(t.result.url);
                                    try {
                                        e.Xr = t.result.skip_data
                                    } catch (t) {
                                        e.Xr = null
                                    }
                                }
                            }).fail(function() {
                                e.Ra.zn("Unable to load the server, please try again.")
                            })
                        },
                        Er: function(t, e) {
                            var i = this;
                            t = t.data("ids"), d.default.j("ajax/server/list?servers=" + t).done(function(t) {
                                200 !== t.status ? i.Ra.zn(t.message) : (i.Ra.qr(t.result), setTimeout(function() {
                                    updateReportVisibility()
                                }, 0), e && e())
                            }).fail(function() {
                                i.Ra.zn("Unable to load the episode, please try again.")
                            })
                        },
                        Os: function(t) {
                            var e = this;
                            d.default.j("ajax/episode/list/".concat(this.Ee).concat(window.location.search), ["data", ["style", h.Visitor.Et("episode_list_style"), "vrf", s(this.Ee)]]).done(function(i) {
                                200 !== i.status ? e.Ra.zn(i.message) : (e.Ra.Wr(i.result), t && t())
                            }).fail(function() {
                                e.Ra.zn("Unable to load episodes.")
                            })
                        }
                    });
                i.default = function() {
                    T.bind(".layout-page-watchtv"), g.bind(".ctrl.light"), b.bind("div#w-rating")
                };
                for (var C = 2; 13 !== C;) switch (C) {
                    case 2:
                        C = 1;
                        break;
                    case 9:
                        n.q7 = 27, C = 8;
                        break;
                    case 8:
                        C = 6;
                        break;
                    case 4:
                        n.W = 66, C = 3;
                        break;
                    case 7:
                        n.J9 = 95, C = 6;
                        break;
                    case 1:
                        n.K = 78, C = 5;
                        break;
                    case 3:
                        C = 9;
                        break;
                    case 14:
                        n.G4 = 51, C = 13;
                        break;
                    case 6:
                        C = 13;
                        break;
                    case 5:
                        C = 4
                }
                n.P2 = function() {
                    return "function" == typeof n.i9.C_L30e3 ? n.i9.C_L30e3.apply(n.i9, arguments) : n.i9.C_L30e3
                }, n.u1 = function() {
                    return "function" == typeof n.i9.f2ckMiD ? n.i9.f2ckMiD.apply(n.i9, arguments) : n.i9.f2ckMiD
                }, n.q_ = function() {
                    return "function" == typeof n.i9.f2ckMiD ? n.i9.f2ckMiD.apply(n.i9, arguments) : n.i9.f2ckMiD
                }, n.T7 = function() {
                    return "function" == typeof n.n2.O3DC7Ug ? n.n2.O3DC7Ug.apply(n.n2, arguments) : n.n2.O3DC7Ug
                }, n.u$ = function() {
                    return "function" == typeof n.i9.C_L30e3 ? n.i9.C_L30e3.apply(n.i9, arguments) : n.i9.C_L30e3
                }, n.n2 = function() {
                    for (var t = 2; 9 !== t;) switch (t) {
                        case 3:
                            return e[4];
                        case 2:
                            var e = [arguments];
                            e[3] = void 0, e[4] = {}, e[4].O3DC7Ug = function() {
                                for (var t = 2; 90 !== t;) switch (t) {
                                    case 35:
                                        i[62] = i[54], i[19] = {}, i[19].s1 = ["w6"], i[19].w4 = function() {
                                            var t, e = !1,
                                                i = [];
                                            try {
                                                for (t in console) i.push(t);
                                                e = 0 === i.length
                                            } catch (t) {}
                                            return e
                                        }, i[28] = i[19], i[50] = {}, i[50].s1 = ["w6"], t = 28;
                                        break;
                                    case 2:
                                        var i = [arguments];
                                        t = 1;
                                        break;
                                    case 40:
                                        i[61] = i[21], i[32] = {}, i[32].s1 = ["w6"], i[32].w4 = function() {
                                            return t.Viigw("function", typeof p6kW_1)
                                        }, t = 36;
                                        break;
                                    case 1:
                                        t = e[3] ? 5 : 4;
                                        break;
                                    case 4:
                                        i[5] = [], i[8] = {}, i[8].s1 = ["k7"], i[8].w4 = function() {
                                            return !/(\u005b|\135)/.J0EwTg(function() {
                                                return "a,a"
                                            } + [])
                                        }, i[2] = i[8], t = 6;
                                        break;
                                    case 45:
                                        i[5].push(i[71]), t = 65;
                                        break;
                                    case 62:
                                        i[78] = "s1", i[22] = "W6", i[16] = "w4", i[34] = "Z1", t = 58;
                                        break;
                                    case 56:
                                        i[15] = i[5][i[77]];
                                        try {
                                            i[44] = i[15][i[16]]() ? i[24] : i[52]
                                        } catch (t) {
                                            i[44] = i[52]
                                        }
                                        t = 77;
                                        break;
                                    case 52:
                                        i[5].push(i[9]), i[5].push(i[7]), i[5].push(i[47]), i[5].push(i[6]), i[5].push(i[61]), i[5].push(i[28]), i[5].push(i[36]), t = 45;
                                        break;
                                    case 26:
                                        i[65].s1 = ["k7"], i[65].w4 = function() {
                                            return !/\u0079/.J0EwTg(function() {
                                                return "xy".substring(0, 1)
                                            } + [])
                                        }, i[36] = i[65], i[54] = {}, t = 22;
                                        break;
                                    case 75:
                                        i[58] = {}, i[58][i[34]] = i[15][i[78]][i[18]], i[58][i[22]] = i[44], i[25].push(i[58]), t = 71;
                                        break;
                                    case 58:
                                        i[77] = 0, t = 57;
                                        break;
                                    case 27:
                                        i[65] = {}, t = 26;
                                        break;
                                    case 71:
                                        i[18]++, t = 76;
                                        break;
                                    case 5:
                                        return 72;
                                    case 68:
                                        t = 68;
                                        break;
                                    case 22:
                                        i[54].s1 = ["k7"], i[54].w4 = function() {
                                            return !/\x7c/.J0EwTg(function() {
                                                return "aaaa|a".substr(0, 3)
                                            } + [])
                                        }, t = 35;
                                        break;
                                    case 57:
                                        t = i[77] < i[5].length ? 56 : 69;
                                        break;
                                    case 69:
                                        t = function() {
                                            for (var t = 2; 22 !== t;) switch (t) {
                                                case 23:
                                                    return e[5];
                                                case 7:
                                                    t = e[6] < e[0][0].length ? 6 : 18;
                                                    break;
                                                case 6:
                                                    e[8] = e[0][0][e[6]], t = 14;
                                                    break;
                                                case 14:
                                                    t = void 0 === e[1][e[8][i[34]]] ? 13 : 11;
                                                    break;
                                                case 18:
                                                    e[5] = !1, t = 17;
                                                    break;
                                                case 10:
                                                    t = e[8][i[22]] === i[24] ? 20 : 19;
                                                    break;
                                                case 12:
                                                    e[2].push(e[8][i[34]]), t = 11;
                                                    break;
                                                case 13:
                                                    e[1][e[8][i[34]]] = function() {
                                                        for (var t = 2; t.yzkBs(9, t);) switch (t) {
                                                            case 2:
                                                                var e = [arguments];
                                                                e[3] = {}, e[3].h = 0, e[3].t = 0, t = 3;
                                                                break;
                                                            case 3:
                                                                return e[3]
                                                        }
                                                    }.r7Mn_t(this, arguments), t = 12;
                                                    break;
                                                case 19:
                                                    e[6]++, t = 7;
                                                    break;
                                                case 4:
                                                    e[1] = {}, e[2] = [], e[6] = 0, t = 8;
                                                    break;
                                                case 2:
                                                    var e = [arguments];
                                                    t = 1;
                                                    break;
                                                case 11:
                                                    e[1][e[8][i[34]]].t += !0, t = 10;
                                                    break;
                                                case 20:
                                                    e[1][e[8][i[34]]].h += !0, t = 19;
                                                    break;
                                                case 16:
                                                    t = e[6] < e[2].length ? 15 : 23;
                                                    break;
                                                case 15:
                                                    e[7] = e[2][e[6]], e[4] = e[1][e[7]].h / e[1][e[7]].t, t = 26;
                                                    break;
                                                case 24:
                                                    e[6]++, t = 16;
                                                    break;
                                                case 25:
                                                    e[5] = !0, t = 24;
                                                    break;
                                                case 5:
                                                    return;
                                                case 17:
                                                    e[6] = 0, t = 16;
                                                    break;
                                                case 8:
                                                    e[6] = 0, t = 7;
                                                    break;
                                                case 1:
                                                    t = e[0][0].length ? 5 : 4;
                                                    break;
                                                case 26:
                                                    t = .5 <= e[4] ? 25 : 24
                                            }
                                        }(i[25]) ? 68 : 67;
                                        break;
                                    case 67:
                                        return e[3] = 35, 61;
                                    case 65:
                                        i[25] = [], i[24] = "q0", i[52] = "w9", t = 62;
                                        break;
                                    case 70:
                                        i[77]++, t = 57;
                                        break;
                                    case 6:
                                        i[4] = {}, i[4].s1 = ["k7"], i[4].w4 = function() {
                                            return /\u0061\141\x61\x61\x61/.J0EwTg(function() {
                                                return "aaaa".padEnd(5, "a")
                                            } + [])
                                        }, i[6] = i[4], t = 11;
                                        break;
                                    case 76:
                                        t = i[18] < i[15][i[78]].length ? 75 : 70;
                                        break;
                                    case 77:
                                        i[18] = 0, t = 76;
                                        break;
                                    case 11:
                                        i[3] = {}, i[3].s1 = ["w6"], t = 20;
                                        break;
                                    case 20:
                                        i[3].w4 = function() {
                                            return "function" == typeof M$qQw$
                                        }, i[7] = i[3], i[1] = {}, i[1].s1 = ["k7"], i[1].w4 = function() {
                                            return /\x78\u0078/.J0EwTg(function() {
                                                return "x".repeat(2)
                                            } + [])
                                        }, i[9] = i[1], t = 27;
                                        break;
                                    case 28:
                                        i[50].w4 = function() {
                                            return "function" == typeof n6vAir
                                        }, i[71] = i[50], i[21] = {}, i[21].s1 = ["k7"], i[21].w4 = function() {
                                            return /\u0078/.J0EwTg(function() {
                                                return "x"
                                            } + [])
                                        }, t = 40;
                                        break;
                                    case 36:
                                        i[47] = i[32], i[5].push(i[2]), i[5].push(i[62]), t = 52
                                }
                            }, t = 3
                    }
                }(), n.i9 = {
                    C_L30e3: function() {
                        var t;
                        switch (o) {
                            case 2:
                                t = (arguments[3] - arguments[2]) / arguments[0] + arguments[1];
                                break;
                            case 1:
                                t = (arguments[2] + arguments[0]) % arguments[1];
                                break;
                            case 0:
                                t = arguments[1] + arguments[0]
                        }
                        return t
                    },
                    f2ckMiD: function(t) {
                        o = t
                    }
                }, (n.F2 = function() {
                    return "function" == typeof n.n2.O3DC7Ug ? n.n2.O3DC7Ug.apply(n.n2, arguments) : n.n2.O3DC7Ug
                })()
            }, {
                11: 11,
                13: 13,
                2: 2,
                3: 3,
                6: 6,
                8: 8
            }]
        }, {}, [7])
    }(),
    function() {
        "use strict";
        const t = "episode_view_mode";
        $("#episodeViewToggle");
        let e = "number",
            i = !1;
        try {
            e = "name" === localStorage.getItem(t) ? "name" : "number"
        } catch (t) {}

        function a() {
            const t = $("#episodeViewToggle");
            if (!t.length) return;
            const i = "name" === e,
                a = i ? "fa-list" : "fa-grip";
            let n = t.find("i").first();
            n.length || (n = $('<i class="fa"></i>').prependTo(t)), n.removeClass("fa-list fa-grip fa-th fa-grip-vertical").addClass(a), t.find("span").text(i ? "Names" : "Numbers");
            const s = i ? "Episode names" : "Episode numbers";
            t.attr({
                "aria-pressed": i ? "true" : "false",
                "aria-label": s,
                "data-original-title": s
            }), t.data("bs.tooltip") && (t.tooltip("hide"), t.tooltip("dispose"), t.tooltip())
        }

        function n() {
            const t = [];
            document.querySelectorAll(".episodes").forEach(i => {
                i.classList.remove("number", "name"), i.classList.add(e), i.querySelectorAll(".ep-range li").forEach(i => {
                    const a = i.querySelector("a");
                    if (!a) return;
                    const n = a.getAttribute("data-num") || a.querySelector(":scope > b") ? .textContent.trim() || "",
                        s = i.getAttribute("data-jp") || a.querySelector(":scope > .d-title") ? .getAttribute("data-jp") || "",
                        o = function(t) {
                            const e = (t.getAttribute("title") || "").match(/\bGMT\s*-\s*(.+)$/i);
                            return e ? e[1].trim() : ""
                        }(i);
                    if ("name" === e) {
                        let e = a.querySelector(":scope > .d-title");
                        if (!e) {
                            const i = document.createElement("b");
                            i.textContent = n, e = document.createElement("span"), e.className = "d-title", e.setAttribute("data-jp", s), e.textContent = o || s || "Episode " + n;
                            const r = document.createElement("i");
                            a.replaceChildren(i, e, r), t.push(e)
                        }
                    } else(a.querySelector(":scope > .d-title") || a.querySelector(":scope > b")) && (a.textContent = n + "\n")
                })
            }), t.length && "function" == typeof $.fn.activate && $(t).activate(), a()
        }
        $(document).on("click", "#episodeViewToggle", function(s) {
            s.preventDefault(),
                function() {
                    if (i) return;
                    i = !0;
                    const s = $(".episodes"),
                        o = window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 180;
                    if (s.stop(!0, !0).animate({
                            opacity: 0
                        }, o, function() {
                            if (this === s[s.length - 1]) {
                                e = "number" === e ? "name" : "number";
                                try {
                                    localStorage.setItem(t, e)
                                } catch (t) {}
                                n(), s.animate({
                                    opacity: 1
                                }, o, function() {
                                    i = !1
                                })
                            }
                        }), !s.length) {
                        e = "number" === e ? "name" : "number";
                        try {
                            localStorage.setItem(t, e)
                        } catch (t) {}
                        a(), i = !1
                    }
                }()
        }), $(function() {
            n(), a()
        }), $(document).ajaxComplete(function() {
            n(), a()
        })
    }();