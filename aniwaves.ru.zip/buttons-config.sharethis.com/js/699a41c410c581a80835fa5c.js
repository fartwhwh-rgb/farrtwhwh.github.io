window.__sharethis__.init({
    "ts": 1771718381034,
    "inline-share-buttons": {
        "alignment": "left",
        "background_color": "#B581A3",
        "color": "social",
        "enabled": true,
        "font_size": 11,
        "has_spacing": true,
        "is_ssb": false,
        "labels": "cta",
        "language": "en",
        "min_count": 10,
        "networks": ["facebook", "twitter", "messenger", "reddit", "whatsapp", "telegram"],
        "num_networks": 6,
        "num_ssb_networks": 6,
        "padding": 8,
        "radius": 5,
        "show_total": true,
        "size": 32,
        "size_label": "small",
        "spacing": 8,
        "text_color": "#fff",
        "use_native_counts": true,
        "ts": 1771718381021,
        "updated_at": "2026-02-21T23:59:41.021Z"
    }
});